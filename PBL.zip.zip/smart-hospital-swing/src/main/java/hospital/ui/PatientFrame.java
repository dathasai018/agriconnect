package hospital.ui;

import hospital.AppContext;
import hospital.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Patient screen: status banner, request form with doctor cards, and visit history. */
public class PatientFrame extends BaseFrame<Map<String, Object>> {
    // status banner
    private final JPanel banner = new JPanel(new BorderLayout(20, 0));
    private final JLabel bTitle = Theme.label("", new Font("Segoe UI", Font.BOLD, 19), Color.WHITE);
    private final JLabel bLine1 = Theme.label("", Theme.BODY, Color.WHITE);
    private final JLabel bLine2 = Theme.label("", Theme.BODY, Color.WHITE);
    private final JLabel bLine3 = Theme.label("", Theme.BODY, Color.WHITE);
    private final JLabel bBig = Theme.label("", Theme.BIG, Color.WHITE);
    private final JLabel bBigSub = Theme.label("", Theme.SMALL, Color.WHITE);
    private final JButton cancelBtn = Theme.button("Cancel request", false);

    // request form
    private final JPanel requestCard = Theme.card();
    private final JTextArea complaint = new JTextArea(3, 40);
    private final JRadioButton[] sev = new JRadioButton[5];
    private final JPanel docGrid = new JPanel(new GridLayout(0, 3, 12, 12));
    private final JButton reqDoctor = Theme.button("Request selected doctor", true);
    private final JButton reqStaff = Theme.button("Let staff choose a doctor for me", false);

    private final Grid history = new Grid("Arrived", "Severity", "Problem", "Doctor", "Status");
    private final JPanel content;

    private List<Map<String, Object>> doctors = new ArrayList<>();
    private Integer selectedDoctor;
    private String docSig = "";

    public PatientFrame(User user, String token) {
        super(user, token, "Patient");

        // --- banner ---
        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        for (JComponent c : new JComponent[]{bTitle, bLine1, bLine2, bLine3}) { c.setAlignmentX(0f); left.add(c); left.add(Box.createVerticalStrut(3)); }
        cancelBtn.setAlignmentX(0f);
        cancelBtn.addActionListener(e -> act(() -> { AppContext.service.cancelMine(this.user); return null; }, "Request cancelled"));
        left.add(Box.createVerticalStrut(6));
        left.add(cancelBtn);
        JPanel bigBox = new JPanel();
        bigBox.setOpaque(false);
        bigBox.setLayout(new BoxLayout(bigBox, BoxLayout.Y_AXIS));
        bBig.setAlignmentX(0.5f);
        bBigSub.setAlignmentX(0.5f);
        bigBox.add(bBig);
        bigBox.add(bBigSub);
        banner.setBorder(new EmptyBorder(16, 20, 16, 20));
        banner.add(left, BorderLayout.CENTER);
        banner.add(bigBox, BorderLayout.EAST);

        // --- request form ---
        complaint.setLineWrap(true);
        complaint.setWrapStyleWord(true);
        Theme.field(complaint);
        ButtonGroup group = new ButtonGroup();
        JPanel sevRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        sevRow.setOpaque(false);
        String[] sevText = {"", "Critical (life-threatening)", "Severe (intense pain, heavy bleeding)", "Moderate (needs care soon)", "Minor (can wait a little)"};
        for (int i = 1; i <= 4; i++) {
            sev[i] = new JRadioButton(sevText[i], i == 3);
            sev[i].setOpaque(false);
            sev[i].setFont(Theme.BOLD);
            sev[i].setForeground(Theme.SEV[i]);
            group.add(sev[i]);
            sevRow.add(sev[i]);
        }
        reqDoctor.setEnabled(false);
        reqDoctor.addActionListener(e -> sendRequest("DOCTOR"));
        reqStaff.addActionListener(e -> sendRequest("STAFF"));
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actions.setOpaque(false);
        actions.add(reqDoctor);
        actions.add(reqStaff);

        docGrid.setOpaque(false);
        JPanel form = Theme.stack(10,
                Theme.label("Get emergency care", Theme.TITLE, Theme.INK),
                Theme.labeled("What is the problem?", new JScrollPane(complaint)),
                Theme.labeled("How serious is it? (staff and doctors can change this after checking you)", sevRow),
                Theme.labeled("Choose your doctor - free doctors can be selected, busy doctors are greyed out", docGrid),
                actions);
        requestCard.add(form, BorderLayout.CENTER);

        // --- history ---
        history.severityColumn(1).statusColumn(4).width(0, 140).width(1, 100).width(2, 360);
        JPanel historyCard = Theme.card();
        historyCard.add(Theme.label("My visits", Theme.TITLE, Theme.INK), BorderLayout.NORTH);
        historyCard.add(history.scroll(170), BorderLayout.CENTER);
        ((BorderLayout) historyCard.getLayout()).setVgap(8);

        content = Theme.stack(14, banner, requestCard, historyCard);
        JScrollPane scroll = new JScrollPane(content);
        scroll.setBorder(null);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        body.add(scroll, BorderLayout.CENTER);
        start();
    }

    @Override protected Map<String, Object> fetch() throws Exception { return AppContext.service.patientView(user); }

    @Override protected void render(Map<String, Object> data) {
        doctors = Theme.maps(data.get("doctors"));
        Map<String, Object> active = Theme.map(data.get("active"));
        updateBanner(active);
        requestCard.setVisible(active == null);
        rebuildDoctors();

        List<Object[]> rows = new ArrayList<>();
        List<Integer> ids = new ArrayList<>();
        for (Map<String, Object> p : Theme.maps(data.get("history"))) {
            String doctor = Theme.s(p, "doctor");
            rows.add(new Object[]{Theme.s(p, "arrival"), Theme.n(p, "severity"), Theme.s(p, "complaint"), doctor.isEmpty() ? "-" : doctor, Theme.s(p, "status")});
            ids.add(Theme.n(p, "id"));
        }
        history.set(rows, ids);
        content.revalidate();
        content.repaint();
    }

    private void updateBanner(Map<String, Object> a) {
        cancelBtn.setVisible(false);
        bBig.setText("");
        bBigSub.setText("");
        bLine3.setText("");
        if (a == null) {
            banner.setBackground(Color.WHITE);
            banner.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Theme.LINE, 1, true), new EmptyBorder(16, 20, 16, 20)));
            setBannerText(Theme.INK, "Hello, " + user.fullName(), "You have no active request. Fill in the form below to get care.", "");
            bLine1.setForeground(Theme.MUTED);
        } else if ("WAITING".equals(Theme.s(a, "status"))) {
            banner.setBackground(new Color(0xC98A00));
            banner.setBorder(new EmptyBorder(16, 20, 16, 20));
            setBannerText(Color.WHITE, "You are in the queue", "[" + Theme.SEV_NAME[Theme.n(a, "severity")] + "]  " + Theme.s(a, "complaint"),
                    "Requested: " + (a.get("preferredDoctorId") != null ? Theme.s(a, "requested") : "Staff will choose a doctor for you"));
            bLine3.setText("Waiting for " + Theme.waited(Theme.s(a, "arrival")) + ". More serious patients are seen first.");
            bBig.setText("#" + Math.max(1, Theme.n(a, "position")));
            bBigSub.setText("your place in line");
            cancelBtn.setVisible(true);
        } else {
            banner.setBackground(Theme.OK);
            banner.setBorder(new EmptyBorder(16, 20, 16, 20));
            String doctorName = Theme.s(a, "doctor"), extra = "";
            for (Map<String, Object> d : doctors)
                if (doctorName.equals(Theme.s(d, "name"))) extra = "  -  " + Theme.s(d, "specialization") + "  -  Room " + Theme.s(d, "room");
            setBannerText(Color.WHITE, "You are being treated", doctorName + extra, "Bed " + Theme.s(a, "bed") + "  -  " + Theme.s(a, "complaint"));
            bBig.setText(Theme.s(a, "bed"));
            bBigSub.setText("your bed");
        }
        banner.revalidate();
    }

    private void setBannerText(Color fg, String title, String l1, String l2) {
        for (JLabel l : new JLabel[]{bTitle, bLine1, bLine2, bLine3, bBig, bBigSub}) l.setForeground(fg);
        bTitle.setText(title);
        bLine1.setText(l1);
        bLine2.setText(l2);
    }

    private void rebuildDoctors() {
        boolean stillFree = false;
        for (Map<String, Object> d : doctors)
            if (selectedDoctor != null && Theme.n(d, "id") == selectedDoctor && "AVAILABLE".equals(Theme.s(d, "status"))) stillFree = true;
        if (!stillFree) selectedDoctor = null;

        StringBuilder sig = new StringBuilder(String.valueOf(selectedDoctor));
        for (Map<String, Object> d : doctors) sig.append('|').append(Theme.s(d, "id")).append(Theme.s(d, "status"));
        if (!sig.toString().equals(docSig)) {
            docSig = sig.toString();
            docGrid.removeAll();
            for (Map<String, Object> d : doctors) {
                int id = Theme.n(d, "id");
                docGrid.add(new DoctorCard(d, selectedDoctor != null && selectedDoctor == id, () -> {
                    selectedDoctor = (selectedDoctor != null && selectedDoctor == id) ? null : id;
                    docSig = "";
                    rebuildDoctors();
                }));
            }
            docGrid.revalidate();
            docGrid.repaint();
        }
        reqDoctor.setEnabled(selectedDoctor != null);
    }

    private void sendRequest(String mode) {
        String text = complaint.getText().trim();
        if (text.isEmpty()) { info("Please describe what is wrong first."); complaint.requestFocus(); return; }
        int severity = 3;
        for (int i = 1; i <= 4; i++) if (sev[i].isSelected()) severity = i;
        Integer doctorId = "DOCTOR".equals(mode) ? selectedDoctor : null;
        if ("DOCTOR".equals(mode) && doctorId == null) { info("Please select a free doctor first."); return; }
        int sevFinal = severity;
        act(() -> AppContext.service.requestTreatment(user, text, sevFinal, mode, doctorId), "Request sent",
                () -> { complaint.setText(""); selectedDoctor = null; docSig = ""; });
    }
}
