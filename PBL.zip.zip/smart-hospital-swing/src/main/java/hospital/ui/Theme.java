package hospital.ui;

import hospital.model.Mappable;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Colours, fonts and small building blocks shared by every screen. */
public final class Theme {
    public static final Color BRAND = new Color(0x0B7285), BRAND_DARK = new Color(0x095C6B), BRAND_SOFT = new Color(0xE3F4F7);
    public static final Color BG = new Color(0xF4F7FB), LINE = new Color(0xE2E8F0), INK = new Color(0x18232F), MUTED = new Color(0x667689);
    public static final Color OK = new Color(0x1F7A45), WARN = new Color(0xC2610C), OFF = new Color(0x6B7889), DANGER = new Color(0xD93025);
    public static final Color[] SEV = { null, new Color(0xD93025), new Color(0xEF6C00), new Color(0xC99200), new Color(0x2E9E5B) };
    public static final String[] SEV_NAME = { "", "Critical", "Severe", "Moderate", "Minor" };

    public static final Font BODY = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font BOLD = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font SMALL = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font SMALL_BOLD = new Font("Segoe UI", Font.BOLD, 11);
    public static final Font TITLE = new Font("Segoe UI", Font.BOLD, 17);
    public static final Font BIG = new Font("Segoe UI", Font.BOLD, 34);

    private Theme() {}

    public static void install() {
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); } catch (Exception ignored) { }
        for (Object key : Collections.list(UIManager.getDefaults().keys()))
            if (UIManager.get(key) instanceof FontUIResource) UIManager.put(key, new FontUIResource(BODY));
        UIManager.put("OptionPane.background", Color.WHITE);
        UIManager.put("Panel.background", Color.WHITE);
    }

    // ---------- small helpers ----------

    public static JLabel label(String text, Font font, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font);
        l.setForeground(color);
        return l;
    }

    public static JButton button(String text, boolean primary) { return new FlatButton(text, primary); }

    public static JPanel card() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(new CompoundBorder(new LineBorder(LINE, 1, true), new EmptyBorder(14, 16, 14, 16)));
        return p;
    }

    /** Vertical stack: every item gets the full width and its own height; extra space goes below. */
    public static JPanel stack(int gap, Component... items) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.weightx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.anchor = GridBagConstraints.NORTH;
        c.insets = new Insets(0, 0, gap, 0);
        int y = 0;
        for (Component it : items) { c.gridy = y++; p.add(it, c); }
        GridBagConstraints f = new GridBagConstraints();
        f.gridx = 0; f.gridy = y; f.weighty = 1; f.fill = GridBagConstraints.BOTH;
        JPanel filler = new JPanel();
        filler.setOpaque(false);
        p.add(filler, f);
        return p;
    }

    public static <T extends JTextComponent> T field(T f) {
        f.setFont(BODY);
        f.setBorder(new CompoundBorder(new LineBorder(LINE, 1, true), new EmptyBorder(7, 9, 7, 9)));
        return f;
    }

    public static <T> JComboBox<T> combo(JComboBox<T> c) {
        c.setFont(BODY);
        c.setBackground(Color.WHITE);
        return c;
    }

    public static JPanel labeled(String text, JComponent c) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setOpaque(false);
        p.add(label(text, SMALL, MUTED), BorderLayout.NORTH);
        p.add(c, BorderLayout.CENTER);
        return p;
    }

    public static JLabel chip(String text) {
        JLabel l = label(" " + text + " ", SMALL_BOLD, BRAND_DARK);
        l.setOpaque(true);
        l.setBackground(BRAND_SOFT);
        l.setBorder(new EmptyBorder(2, 6, 2, 6));
        return l;
    }

    public static JLabel avatar(String name, int size) {
        String[] w = name.replace("Dr.", "").trim().split("\\s+");
        String ini = (w[0].isEmpty() ? "?" : w[0].substring(0, 1)) + (w.length > 1 ? w[1].substring(0, 1) : "");
        JLabel l = new JLabel(ini.toUpperCase(), SwingConstants.CENTER) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BRAND);
                g2.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        l.setOpaque(false);
        l.setFont(BOLD);
        l.setForeground(Color.WHITE);
        l.setPreferredSize(new Dimension(size, size));
        return l;
    }

    public static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    public static String friendly(String status) {
        return switch (status == null ? "" : status) {
            case "AVAILABLE", "FREE" -> "Free";
            case "BUSY" -> "Busy";
            case "OCCUPIED" -> "Occupied";
            case "OFF_DUTY" -> "Off duty";
            case "WAITING" -> "Waiting";
            case "IN_TREATMENT" -> "In treatment";
            case "DISCHARGED" -> "Discharged";
            case "CANCELLED" -> "Cancelled";
            default -> status == null ? "" : status;
        };
    }

    public static Color statusColor(String status) {
        return switch (status == null ? "" : status) {
            case "AVAILABLE", "FREE", "DISCHARGED" -> OK;
            case "BUSY", "OCCUPIED", "WAITING" -> WARN;
            case "IN_TREATMENT" -> BRAND_DARK;
            default -> OFF;
        };
    }

    public static String waited(String arrival) {
        try {
            long mins = Math.max(0, Duration.between(LocalDateTime.parse(arrival.replace(' ', 'T')), LocalDateTime.now()).toMinutes());
            return mins < 60 ? mins + " min" : (mins / 60) + " h " + (mins % 60) + " m";
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- data helpers ----------

    @SuppressWarnings("unchecked")
    public static Map<String, Object> map(Object o) {
        if (o == null) return null;
        if (o instanceof Mappable m) return m.toMap();
        return (Map<String, Object>) o;
    }

    public static List<Map<String, Object>> maps(Object list) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (list instanceof Iterable<?> it) for (Object o : it) out.add(map(o));
        return out;
    }

    public static String s(Map<String, Object> m, String key) {
        Object v = m.get(key);
        return v == null ? "" : String.valueOf(v);
    }

    public static int n(Map<String, Object> m, String key) {
        return m.get(key) instanceof Number x ? x.intValue() : 0;
    }

    // ---------- tables ----------

    public static JTable table(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setFont(BODY);
        t.setRowHeight(32);
        t.setGridColor(LINE);
        t.setShowVerticalLines(false);
        t.setIntercellSpacing(new Dimension(0, 1));
        t.setFillsViewportHeight(true);
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.setSelectionBackground(BRAND_SOFT);
        t.setSelectionForeground(INK);
        t.setForeground(INK);
        t.setDefaultRenderer(Object.class, new PadRenderer());
        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setPreferredSize(new Dimension(100, 34));
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tb, v, false, false, r, c);
                setBackground(BG);
                setForeground(MUTED);
                setFont(SMALL_BOLD);
                setBorder(new CompoundBorder(new MatteBorder(0, 0, 1, 0, LINE), new EmptyBorder(0, 10, 0, 10)));
                return this;
            }
        });
        return t;
    }

    private static class PadRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            super.getTableCellRendererComponent(t, v, sel, false, r, c);
            setBorder(new EmptyBorder(0, 10, 0, 10));
            return this;
        }
    }

    public static final class SeverityRenderer extends PadRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            super.getTableCellRendererComponent(t, "", sel, foc, r, c);
            int lvl = v instanceof Number n ? n.intValue() : 0;
            if (lvl >= 1 && lvl <= 4) { setText("\u25CF " + SEV_NAME[lvl]); setForeground(SEV[lvl]); setFont(BOLD); }
            return this;
        }
    }

    public static final class StatusRenderer extends PadRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            String raw = v == null ? "" : v.toString();
            super.getTableCellRendererComponent(t, friendly(raw), sel, foc, r, c);
            setForeground(statusColor(raw));
            setFont(BOLD);
            return this;
        }
    }

    // ---------- flat rounded button ----------

    private static final class FlatButton extends JButton {
        private final boolean primary;
        private boolean hover;

        FlatButton(String text, boolean primary) {
            super(text);
            this.primary = primary;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setOpaque(false);
            setFont(BOLD);
            setForeground(primary ? Color.WHITE : INK);
            setBorder(new EmptyBorder(8, 16, 8, 16));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
            });
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color fill;
            if (!isEnabled()) fill = primary ? new Color(0xA9CFD6) : new Color(0xF1F5F9);
            else if (primary) fill = hover ? BRAND_DARK : BRAND;
            else fill = hover ? new Color(0xF1F5F9) : Color.WHITE;
            boolean active = Boolean.TRUE.equals(getClientProperty("active"));
            if (active) fill = BRAND_SOFT;
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
            if (!primary) { g2.setColor(active ? BRAND : LINE); g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10); }
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
