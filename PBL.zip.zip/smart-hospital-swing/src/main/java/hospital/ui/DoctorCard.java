package hospital.ui;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;

/** A doctor profile card shown to patients. Free doctors can be clicked to select. */
final class DoctorCard extends JPanel {
    DoctorCard(Map<String, Object> d, boolean selected, Runnable onClick) {
        super(new BorderLayout(0, 8));
        String status = Theme.s(d, "status");
        boolean free = "AVAILABLE".equals(status);

        setBackground(selected ? Theme.BRAND_SOFT : Color.WHITE);
        setBorder(new CompoundBorder(new LineBorder(selected ? Theme.BRAND : Theme.LINE, 2, true), new EmptyBorder(12, 14, 12, 14)));

        JPanel nameBox = new JPanel();
        nameBox.setOpaque(false);
        nameBox.setLayout(new BoxLayout(nameBox, BoxLayout.Y_AXIS));
        JLabel name = Theme.label(Theme.s(d, "name"), new Font("Segoe UI", Font.BOLD, 15), free ? Theme.INK : Theme.MUTED);
        name.setAlignmentX(0f);
        JLabel chip = Theme.chip(Theme.s(d, "specialization"));
        chip.setAlignmentX(0f);
        nameBox.add(name);
        nameBox.add(Box.createVerticalStrut(4));
        nameBox.add(chip);

        JPanel top = new JPanel(new BorderLayout(10, 0));
        top.setOpaque(false);
        top.add(Theme.avatar(Theme.s(d, "name"), 44), BorderLayout.WEST);
        top.add(nameBox, BorderLayout.CENTER);

        JLabel details = Theme.label("<html><div style='width:230px'>" + Theme.esc(Theme.s(d, "qualification")) + " &middot; "
                + Theme.n(d, "experience") + " yrs experience &middot; Room " + Theme.esc(Theme.s(d, "room"))
                + "<br><span style='color:#667689'>" + Theme.esc(Theme.s(d, "about")) + "</span></div></html>",
                Theme.SMALL, free ? Theme.INK : Theme.MUTED);

        JPanel foot = new JPanel(new BorderLayout());
        foot.setOpaque(false);
        foot.add(Theme.label("\u25CF " + Theme.friendly(status), Theme.BOLD, Theme.statusColor(status)), BorderLayout.WEST);
        foot.add(Theme.label(free ? (selected ? "Selected" : "Click to select") : "Not available", Theme.SMALL, Theme.MUTED), BorderLayout.EAST);

        add(top, BorderLayout.NORTH);
        add(details, BorderLayout.CENTER);
        add(foot, BorderLayout.SOUTH);

        if (free) {
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) { onClick.run(); }
            });
        }
    }
}
