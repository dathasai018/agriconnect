package hospital.ui;

import hospital.AppContext;
import hospital.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Doctor screen: own profile + duty status, current patient, and waiting patients (most serious first). */
public class DoctorFrame extends BaseFrame<Map<String, Object>> {
    private final JPanel profile = Theme.card();
    private final JLabel nameLbl = Theme.label("", Theme.TITLE, Theme.INK);
    private final JPanel chipBox = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    private final JLabel detailLbl = Theme.label("", Theme.SMALL, Theme.MUTED);
    private final JLabel statusLbl = Theme.label("", Theme.BOLD, Theme.INK);
    private final JButton toggleBtn = Theme.button("", false);
    private final JLabel avatarHolder = new JLabel();
    private final JPanel avatarBox = new JPanel(new BorderLayout());
    private String toggleTo = "OFF_DUTY";
    private String shownName = "";

    private final JPanel current = new JPanel(new BorderLayout(16, 0));
    private final JLabel curTitle = Theme.label("", new Font("Segoe UI", Font.BOLD, 18), Color.WHITE);
    private final JLabel curLine1 = Theme.label("", Theme.BODY, Color.WHITE);
    private final JLabel curLine2 = Theme.label("", Theme.BODY, Color.WHITE);
    private final JButton dischargeBtn = Theme.button("Finish & discharge", false);
    private Integer currentId;

    private final Grid queue = new Grid("Severity", "Patient", "Age / Gender", "Problem", "Waiting", "Request", "You can");
    private final JButton takeBtn = Theme.button("Take selected patient", true);
    private final JLabel bedsLbl = Theme.label("", Theme.SMALL, Theme.MUTED);
    private final JLabel hint = Theme.label(" ", Theme.SMALL, Theme.MUTED);
    private final Map<Integer, Boolean> canTake = new HashMap<>();
    private int myId;
    private final JPanel content;

    public DoctorFrame(User user, String token) {
        super(user, token, "Doctor");

        // --- profile ---
        avatarBox.setOpaque(false);
        avatarBox.add(avatarHolder, BorderLayout.CENTER);
        JPanel info = new JPanel();
        info.setOpaque(false);
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        chipBox.setOpaque(false);
        for (JComponent c : new JComponent[]{nameLbl, chipBox, detailLbl}) { c.setAlignmentX(0f); info.add(c); info.add(Box.createVerticalStrut(3)); }
        JPanel left = new JPanel(new BorderLayout(12, 0));
        left.setOpaque(false);
        left.add(avatarBox, BorderLayout.WEST);
        left.add(info, BorderLayout.CENTER);
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 8));
        right.setOpaque(false);
        right.add(statusLbl);
        right.add(toggleBtn);
        toggleBtn.addActionListener(e -> act(() -> { AppContext.service.setDoctorStatus(this.user, myId, toggleTo); return null; }, "Status updated"));
        profile.add(left, BorderLayout.CENTER);
        profile.add(right, BorderLayout.EAST);

        // --- current patient ---
        current.setBackground(Theme.OK);
        current.setBorder(new EmptyBorder(14, 20, 14, 20));
        JPanel cl = new JPanel();
        cl.setOpaque(false);
        cl.setLayout(new BoxLayout(cl, BoxLayout.Y_AXIS));
        cl.add(curTitle);
        cl.add(Box.createVerticalStrut(4));
        cl.add(curLine1);
        cl.add(Box.createVerticalStrut(2));
        cl.add(curLine2);
        current.add(cl, BorderLayout.CENTER);
        JPanel cr = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 10));
        cr.setOpaque(false);
        cr.add(dischargeBtn);
        current.add(cr, BorderLayout.EAST);
        dischargeBtn.addActionListener(e -> {
            if (currentId == null) return;
            int id = currentId;
            act(() -> { AppContext.service.discharge(this.user, id); return null; }, "Patient discharged");
        });
        current.setVisible(false);

        // --- waiting patients ---
        queue.severityColumn(0).width(0, 100).width(1, 150).width(2, 100).width(3, 300).width(4, 80).width(5, 130).width(6, 210);
        takeBtn.setEnabled(false);
        takeBtn.addActionListener(e -> {
            Integer id = queue.selectedId();
            if (id == null) { info("Select a patient in the list first."); return; }
            act(() -> AppContext.service.doctorTake(this.user, id));
        });
        queue.table.getSelectionModel().addListSelectionListener(e -> updateTake());

        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.add(Theme.label("Waiting patients - most serious first", Theme.TITLE, Theme.INK), BorderLayout.WEST);
        head.add(bedsLbl, BorderLayout.EAST);
        JPanel foot = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        foot.setOpaque(false);
        foot.add(takeBtn);
        foot.add(hint);
        JPanel queueCard = Theme.card();
        ((BorderLayout) queueCard.getLayout()).setVgap(10);
        queueCard.add(head, BorderLayout.NORTH);
        queueCard.add(queue.scroll(300), BorderLayout.CENTER);
        queueCard.add(foot, BorderLayout.SOUTH);

        content = new JPanel(new BorderLayout(0, 14));
        content.setOpaque(false);
        content.add(Theme.stack(14, profile, current), BorderLayout.NORTH);
        content.add(queueCard, BorderLayout.CENTER);
        body.add(content, BorderLayout.CENTER);
        start();
    }

    @Override protected Map<String, Object> fetch() throws Exception { return AppContext.service.doctorView(user); }

    @Override protected void render(Map<String, Object> data) {
        Map<String, Object> me = Theme.map(data.get("me"));
        myId = Theme.n(me, "id");
        String status = Theme.s(me, "status");

        if (!shownName.equals(Theme.s(me, "name"))) {
            shownName = Theme.s(me, "name");
            avatarBox.removeAll();
            avatarBox.add(Theme.avatar(shownName, 52), BorderLayout.CENTER);
            chipBox.removeAll();
            chipBox.add(Theme.chip(Theme.s(me, "specialization")));
            nameLbl.setText(shownName);
            detailLbl.setText(Theme.s(me, "qualification") + "  -  " + Theme.n(me, "experience") + " yrs  -  Room " + Theme.s(me, "room"));
        }
        statusLbl.setText("\u25CF " + Theme.friendly(status));
        statusLbl.setForeground(Theme.statusColor(status));
        boolean off = "OFF_DUTY".equals(status);
        toggleTo = off ? "AVAILABLE" : "OFF_DUTY";
        toggleBtn.setText(off ? "Go on duty" : "Go off duty");
        toggleBtn.setEnabled(!"BUSY".equals(status));

        Map<String, Object> cur = Theme.map(data.get("current"));
        current.setVisible(cur != null);
        currentId = cur == null ? null : Theme.n(cur, "id");
        if (cur != null) {
            curTitle.setText("Current patient: " + Theme.s(cur, "name"));
            curLine1.setText("[" + Theme.SEV_NAME[Theme.n(cur, "severity")] + "]  " + Theme.n(cur, "age") + " yrs, "
                    + Theme.s(cur, "gender").toLowerCase() + "  -  " + Theme.s(cur, "complaint"));
            curLine2.setText("Bed " + Theme.s(cur, "bed"));
        }

        bedsLbl.setText(data.get("freeBeds") + " bed(s) free");
        List<Object[]> rows = new ArrayList<>();
        List<Integer> ids = new ArrayList<>();
        canTake.clear();
        for (Map<String, Object> p : Theme.maps(data.get("queue"))) {
            int id = Theme.n(p, "id");
            boolean can = Boolean.TRUE.equals(p.get("canTake"));
            canTake.put(id, can);
            String you = can ? "Can take now" : "AVAILABLE".equals(status) ? "Locked - more serious first"
                    : "BUSY".equals(status) ? "Finish current patient" : "Go on duty first";
            rows.add(new Object[]{Theme.n(p, "severity"), Theme.s(p, "name"), Theme.n(p, "age") + " / " + Theme.s(p, "gender").toLowerCase(),
                    Theme.s(p, "complaint"), Theme.waited(Theme.s(p, "arrival")),
                    Boolean.TRUE.equals(p.get("forYou")) ? "Chose you" : "Any doctor", you});
            ids.add(id);
        }
        queue.set(rows, ids);
        hint.setText(rows.isEmpty() ? "No patients are waiting for you." : "Select a patient and click Take. Only the most serious group can be taken.");
        updateTake();
    }

    private void updateTake() {
        Integer id = queue.selectedId();
        takeBtn.setEnabled(id != null && Boolean.TRUE.equals(canTake.get(id)));
    }
}
