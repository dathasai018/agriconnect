package hospital.ui;

import hospital.AppContext;
import hospital.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Staff screen: live stats, triage queue with assignment, treatment, doctors, beds, log, walk-in registration. */
public class StaffFrame extends BaseFrame<Map<String, Object>> {
    private record Choice(String key, String label) { @Override public String toString() { return label; } }

    private static final String[] STAT_NAMES = {"Waiting", "Critical waiting", "In treatment", "Doctors free", "Beds free", "Discharged today"};
    private final JLabel[] statValue = new JLabel[STAT_NAMES.length];

    private final Grid queue = new Grid("#", "Severity", "Patient", "Age / Gender", "Problem", "Waiting", "Requested doctor", "Source");
    private final JComboBox<Choice> doctorCombo = Theme.combo(new JComboBox<>());
    private final JComboBox<String> sevCombo = Theme.combo(new JComboBox<>(new String[]{"1 - Critical", "2 - Severe", "3 - Moderate", "4 - Minor"}));
    private String comboSig = "";

    private final Grid treat = new Grid("Severity", "Patient", "Problem", "Doctor", "Bed");
    private final Grid doctors = new Grid("Doctor", "Specialization", "Qualification", "Experience", "Room", "Status");
    private final Grid done = new Grid("Patient", "Problem", "Doctor", "Discharged");
    private final JPanel bedGrid = new JPanel(new GridLayout(0, 3, 8, 8));
    private final DefaultListModel<String> logModel = new DefaultListModel<>();

    public StaffFrame(User user, String token) {
        super(user, token, "Staff");

        JPanel stats = new JPanel(new GridLayout(1, STAT_NAMES.length, 12, 0));
        stats.setOpaque(false);
        for (int i = 0; i < STAT_NAMES.length; i++) {
            JPanel c = Theme.card();
            statValue[i] = Theme.label("0", new Font("Segoe UI", Font.BOLD, 26), Theme.INK);
            c.add(statValue[i], BorderLayout.CENTER);
            c.add(Theme.label(STAT_NAMES[i], Theme.SMALL, Theme.MUTED), BorderLayout.SOUTH);
            stats.add(c);
        }

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(Theme.BOLD);
        tabs.addTab("Triage queue", queueTab());
        tabs.addTab("In treatment", treatTab());
        tabs.addTab("Doctors", doctorsTab());
        tabs.addTab("Beds & activity", bedsTab());
        tabs.addTab("Register walk-in", walkInTab());
        tabs.addTab("Discharged", wrap(done.scroll(300)));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.setBorder(new EmptyBorder(0, 0, 12, 0));
        top.add(stats, BorderLayout.CENTER);
        body.add(top, BorderLayout.NORTH);
        body.add(tabs, BorderLayout.CENTER);
        start();
    }

    // ---------------- tabs ----------------

    private JPanel wrap(Component c) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(12, 12, 12, 12));
        p.add(c, BorderLayout.CENTER);
        return p;
    }

    private JPanel buttonRow(Component... items) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        row.setOpaque(false);
        for (Component c : items) row.add(c);
        return row;
    }

    private JPanel queueTab() {
        queue.severityColumn(1).width(0, 40).width(1, 100).width(2, 150).width(3, 90).width(4, 280).width(5, 80).width(6, 170).width(7, 80);
        JButton assign = Theme.button("Assign selected", true);
        assign.addActionListener(e -> {
            Integer id = need(queue, "patient");
            Choice c = (Choice) doctorCombo.getSelectedItem();
            if (id != null && c != null) act(() -> AppContext.service.assignTo(id, c.key()));
        });
        JButton next = Theme.button("Assign next automatically", false);
        next.addActionListener(e -> act(() -> AppContext.service.assignNext()));
        JButton resev = Theme.button("Change severity", false);
        resev.addActionListener(e -> {
            Integer id = need(queue, "patient");
            int level = sevCombo.getSelectedIndex() + 1;
            if (id != null) act(() -> { AppContext.service.changeSeverity(id, level); return null; }, "Severity updated");
        });
        JPanel controls = buttonRow(Theme.label("Doctor:", Theme.BODY, Theme.MUTED), doctorCombo, assign, next,
                Box.createHorizontalStrut(16), Theme.label("Severity:", Theme.BODY, Theme.MUTED), sevCombo, resev);
        doctorCombo.setPreferredSize(new Dimension(210, 32));
        JPanel p = wrap(queue.scroll(300));
        p.add(controls, BorderLayout.SOUTH);
        return p;
    }

    private JPanel treatTab() {
        treat.severityColumn(0).width(0, 100).width(1, 170).width(2, 320);
        JButton discharge = Theme.button("Discharge selected", false);
        discharge.setForeground(Theme.DANGER);
        discharge.addActionListener(e -> {
            Integer id = need(treat, "patient");
            if (id != null) act(() -> { AppContext.service.discharge(this.user, id); return null; }, "Patient discharged");
        });
        JPanel p = wrap(treat.scroll(300));
        p.add(buttonRow(discharge), BorderLayout.SOUTH);
        return p;
    }

    private JPanel doctorsTab() {
        doctors.statusColumn(5).width(0, 160).width(1, 150).width(2, 200);
        JButton on = Theme.button("Set available", false);
        JButton off = Theme.button("Set off duty", false);
        on.addActionListener(e -> setStatus("AVAILABLE"));
        off.addActionListener(e -> setStatus("OFF_DUTY"));
        JPanel p = wrap(doctors.scroll(300));
        p.add(buttonRow(on, off), BorderLayout.SOUTH);
        return p;
    }

    private void setStatus(String status) {
        Integer id = need(doctors, "doctor");
        if (id != null) act(() -> { AppContext.service.setDoctorStatus(this.user, id, status); return null; }, "Status updated");
    }

    private JPanel bedsTab() {
        bedGrid.setOpaque(false);
        JPanel bedCard = Theme.card();
        ((BorderLayout) bedCard.getLayout()).setVgap(10);
        bedCard.add(Theme.label("Beds", Theme.TITLE, Theme.INK), BorderLayout.NORTH);
        bedCard.add(bedGrid, BorderLayout.CENTER);
        JPanel bedHolder = new JPanel(new BorderLayout());
        bedHolder.setOpaque(false);
        bedHolder.add(bedCard, BorderLayout.NORTH);

        JList<String> log = new JList<>(logModel);
        log.setFont(Theme.SMALL);
        JPanel logCard = Theme.card();
        ((BorderLayout) logCard.getLayout()).setVgap(10);
        logCard.add(Theme.label("Activity log", Theme.TITLE, Theme.INK), BorderLayout.NORTH);
        logCard.add(new JScrollPane(log), BorderLayout.CENTER);

        JPanel p = new JPanel(new GridLayout(1, 2, 14, 0));
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(12, 12, 12, 12));
        p.add(bedHolder);
        p.add(logCard);
        return p;
    }

    private JPanel walkInTab() {
        JTextField name = Theme.field(new JTextField());
        JTextField age = Theme.field(new JTextField());
        JComboBox<String> gender = Theme.combo(new JComboBox<>(new String[]{"Male", "Female", "Other"}));
        JTextField complaint = Theme.field(new JTextField());
        JComboBox<String> sev = Theme.combo(new JComboBox<>(new String[]{"1 - Critical", "2 - Severe", "3 - Moderate", "4 - Minor"}));
        sev.setSelectedIndex(2);
        JButton add = Theme.button("Add to queue", true);
        add.addActionListener(e -> {
            int ageNum;
            try { ageNum = Integer.parseInt(age.getText().trim()); } catch (NumberFormatException ex) { info("Age must be a number."); return; }
            String n = name.getText(), g = String.valueOf(gender.getSelectedItem()).toUpperCase(), c = complaint.getText();
            int level = sev.getSelectedIndex() + 1;
            act(() -> AppContext.service.registerWalkIn(n, ageNum, g, c, level), "Patient added to the queue",
                    () -> { name.setText(""); age.setText(""); complaint.setText(""); sev.setSelectedIndex(2); });
        });
        JPanel row = new JPanel(new GridLayout(1, 2, 10, 0));
        row.setOpaque(false);
        row.add(Theme.labeled("Age", age));
        row.add(Theme.labeled("Gender", gender));
        JPanel form = Theme.stack(10, Theme.label("Register walk-in patient", Theme.TITLE, Theme.INK), Theme.labeled("Name", name), row,
                Theme.labeled("Complaint", complaint), Theme.labeled("Severity", sev), add);
        JPanel card = Theme.card();
        card.add(form, BorderLayout.CENTER);
        card.setPreferredSize(new Dimension(460, 430));
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        p.setBackground(Color.WHITE);
        p.add(card);
        return p;
    }

    /** The id of the selected row, or null (with a friendly message) if nothing is selected. */
    private Integer need(Grid g, String what) {
        Integer id = g.selectedId();
        if (id == null) info("Select a " + what + " in the table first.");
        return id;
    }

    // ---------------- data ----------------

    @Override protected Map<String, Object> fetch() throws Exception { return AppContext.service.staffView(); }

    @Override protected void render(Map<String, Object> d) {
        Map<String, Object> s = Theme.map(d.get("stats"));
        String[] values = {Theme.s(s, "waiting"), Theme.s(s, "criticalWaiting"), Theme.s(s, "inTreatment"),
                Theme.s(s, "doctorsAvailable") + " / " + Theme.s(s, "doctorsTotal"), Theme.s(s, "bedsFree") + " / " + Theme.s(s, "bedsTotal"),
                Theme.s(s, "dischargedToday")};
        for (int i = 0; i < values.length; i++) statValue[i].setText(values[i]);
        statValue[1].setForeground(Theme.n(s, "criticalWaiting") > 0 ? Theme.DANGER : Theme.INK);

        List<Map<String, Object>> docs = Theme.maps(d.get("doctors"));
        updateDoctorCombo(docs);

        // queue
        List<Object[]> rows = new ArrayList<>();
        List<Integer> ids = new ArrayList<>();
        int pos = 1;
        for (Map<String, Object> p : Theme.maps(d.get("queue"))) {
            rows.add(new Object[]{pos++, Theme.n(p, "severity"), Theme.s(p, "name"), Theme.n(p, "age") + " / " + Theme.s(p, "gender").toLowerCase(),
                    Theme.s(p, "complaint"), Theme.waited(Theme.s(p, "arrival")),
                    p.get("preferredDoctorId") != null ? Theme.s(p, "requested") : "Staff choice",
                    Boolean.TRUE.equals(p.get("selfService")) ? "Online" : "Walk-in"});
            ids.add(Theme.n(p, "id"));
        }
        queue.set(rows, ids);

        // in treatment
        rows = new ArrayList<>();
        ids = new ArrayList<>();
        for (Map<String, Object> p : Theme.maps(d.get("inTreatment"))) {
            rows.add(new Object[]{Theme.n(p, "severity"), Theme.s(p, "name"), Theme.s(p, "complaint"), Theme.s(p, "doctor"), Theme.s(p, "bed")});
            ids.add(Theme.n(p, "id"));
        }
        treat.set(rows, ids);

        // doctors
        rows = new ArrayList<>();
        ids = new ArrayList<>();
        for (Map<String, Object> x : docs) {
            rows.add(new Object[]{Theme.s(x, "name"), Theme.s(x, "specialization"), Theme.s(x, "qualification"),
                    Theme.n(x, "experience") + " yrs", Theme.s(x, "room"), Theme.s(x, "status")});
            ids.add(Theme.n(x, "id"));
        }
        doctors.set(rows, ids);

        // discharged
        rows = new ArrayList<>();
        ids = new ArrayList<>();
        int shown = 0;
        for (Map<String, Object> p : Theme.maps(d.get("discharged"))) {
            if (shown++ >= 20) break;
            String doc = Theme.s(p, "doctor");
            rows.add(new Object[]{Theme.s(p, "name"), Theme.s(p, "complaint"), doc.isEmpty() ? "-" : doc, Theme.s(p, "discharge")});
            ids.add(Theme.n(p, "id"));
        }
        done.set(rows, ids);

        // beds
        bedGrid.removeAll();
        for (Map<String, Object> b : Theme.maps(d.get("beds"))) {
            boolean free = "FREE".equals(Theme.s(b, "status"));
            JLabel cell = new JLabel("<html><center><b>" + Theme.esc(Theme.s(b, "bedNo")) + "</b><br><span style='font-size:9px'>"
                    + Theme.esc(Theme.s(b, "ward").toLowerCase()) + " - " + (free ? "free" : "occupied") + "</span></center></html>", SwingConstants.CENTER);
            cell.setOpaque(true);
            cell.setFont(Theme.SMALL);
            cell.setForeground(free ? Theme.OK : Theme.WARN);
            cell.setBackground(free ? new Color(0xE8F6EE) : new Color(0xFFF1E0));
            cell.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(free ? new Color(0xBFE5CD) : new Color(0xF3D2A8)), new EmptyBorder(8, 6, 8, 6)));
            bedGrid.add(cell);
        }
        bedGrid.revalidate();
        bedGrid.repaint();

        // log
        logModel.clear();
        for (Map<String, Object> l : Theme.maps(d.get("log"))) {
            String t = Theme.s(l, "time");
            logModel.addElement((t.length() >= 16 ? t.substring(5, 16) : t) + "   " + Theme.s(l, "action"));
        }
    }

    /** Rebuild the doctor drop-down only when the set of free doctors changes (so an open list is not closed). */
    private void updateDoctorCombo(List<Map<String, Object>> docs) {
        StringBuilder sig = new StringBuilder();
        for (Map<String, Object> x : docs) if ("AVAILABLE".equals(Theme.s(x, "status"))) sig.append(Theme.s(x, "id")).append(',');
        if (sig.toString().equals(comboSig)) return;
        comboSig = sig.toString();
        Choice keep = (Choice) doctorCombo.getSelectedItem();
        DefaultComboBoxModel<Choice> m = new DefaultComboBoxModel<>();
        m.addElement(new Choice("auto", "Best match (automatic)"));
        m.addElement(new Choice("random", "Random free doctor"));
        for (Map<String, Object> x : docs)
            if ("AVAILABLE".equals(Theme.s(x, "status"))) m.addElement(new Choice(Theme.s(x, "id"), Theme.s(x, "name") + " (" + Theme.s(x, "specialization") + ")"));
        doctorCombo.setModel(m);
        if (keep != null)
            for (int i = 0; i < m.getSize(); i++) if (m.getElementAt(i).key().equals(keep.key())) doctorCombo.setSelectedIndex(i);
    }
}
