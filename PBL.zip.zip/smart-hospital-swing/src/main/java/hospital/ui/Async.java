package hospital.ui;

import javax.swing.SwingWorker;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

/** Runs database work off the Swing thread so the window never freezes. */
public final class Async {
    private Async() {}

    public static <T> void run(Callable<T> job, Consumer<T> onOk, Consumer<Exception> onError) {
        new SwingWorker<T, Void>() {
            @Override protected T doInBackground() throws Exception { return job.call(); }

            @Override protected void done() {
                try {
                    onOk.accept(get());
                } catch (ExecutionException e) {
                    Throwable c = e.getCause();
                    onError.accept(c instanceof Exception ex ? ex : new Exception(c));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }.execute();
    }
}
