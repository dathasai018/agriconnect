package hospital.ui;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;

/** A read-only table whose rows are tied to ids, keeping the selected row across refreshes. */
public final class Grid {
    public final DefaultTableModel model;
    public final JTable table;
    private final List<Integer> ids = new ArrayList<>();

    public Grid(String... columns) {
        model = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = Theme.table(model);
    }

    public Grid severityColumn(int col) { table.getColumnModel().getColumn(col).setCellRenderer(new Theme.SeverityRenderer()); return this; }
    public Grid statusColumn(int col) { table.getColumnModel().getColumn(col).setCellRenderer(new Theme.StatusRenderer()); return this; }
    public Grid width(int col, int w) { table.getColumnModel().getColumn(col).setPreferredWidth(w); return this; }

    public void set(List<Object[]> rows, List<Integer> rowIds) {
        Integer keep = selectedId();
        model.setRowCount(0);
        ids.clear();
        for (int i = 0; i < rows.size(); i++) { model.addRow(rows.get(i)); ids.add(rowIds.get(i)); }
        if (keep != null) {
            int idx = ids.indexOf(keep);
            if (idx >= 0) table.setRowSelectionInterval(idx, idx);
        }
    }

    public Integer selectedId() {
        int r = table.getSelectedRow();
        return (r < 0 || r >= ids.size()) ? null : ids.get(r);
    }

    public JScrollPane scroll(int preferredHeight) {
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(new javax.swing.border.LineBorder(Theme.LINE));
        sp.getViewport().setBackground(java.awt.Color.WHITE);
        sp.setPreferredSize(new Dimension(400, preferredHeight));
        return sp;
    }
}
