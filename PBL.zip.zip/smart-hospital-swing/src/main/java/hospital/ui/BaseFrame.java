package hospital.ui;

import hospital.AppContext;
import hospital.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Map;
import java.util.concurrent.Callable;

/**
 * Common window: teal header with the user's name and a Log out button, a footer message line,
 * and an automatic refresh every 5 seconds so the screen stays live.
 */
public abstract class BaseFrame<T> extends JFrame {
    protected final User user;
    protected final JPanel body = new JPanel(new BorderLayout());
    private final JLabel footer = Theme.label(" ", Theme.SMALL, Theme.MUTED);
    private final Timer poll;
    private final Timer footerClear;
    private boolean loading;

    protected BaseFrame(User user, String token, String heading) {
        super("Smart Hospital - " + heading);
        this.user = user;

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Theme.BRAND);
        header.setBorder(new EmptyBorder(10, 20, 10, 20));
        header.add(Theme.label("+  Smart Hospital", new Font("Segoe UI", Font.BOLD, 18), Color.WHITE), BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        JLabel role = Theme.label(user.role(), Theme.SMALL_BOLD, Theme.BRAND);
        role.setOpaque(true);
        role.setBackground(Color.WHITE);
        role.setBorder(new EmptyBorder(3, 9, 3, 9));
        JButton logout = Theme.button("Log out", false);
        logout.addActionListener(e -> { dispose(); new LoginFrame().setVisible(true); });
        right.add(role);
        right.add(Theme.label(user.fullName(), Theme.BODY, Color.WHITE));
        right.add(logout);
        header.add(right, BorderLayout.EAST);

        body.setBackground(Theme.BG);
        body.setBorder(new EmptyBorder(16, 18, 8, 18));
        footer.setBorder(new EmptyBorder(4, 20, 8, 20));
        footer.setOpaque(true);
        footer.setBackground(Theme.BG);

        JPanel root = new JPanel(new BorderLayout());
        root.add(header, BorderLayout.NORTH);
        root.add(body, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);

        poll = new Timer(5000, e -> refresh());
        footerClear = new Timer(6000, e -> footer.setText(" "));
        footerClear.setRepeats(false);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosed(WindowEvent e) { poll.stop(); AppContext.auth.logout(token); }
        });
        setSize(1180, 780);
        setMinimumSize(new Dimension(900, 600));
        setLocationByPlatform(true);
    }

    /** Load this screen's data (runs on a background thread). */
    protected abstract T fetch() throws Exception;

    /** Show the loaded data (runs on the Swing thread). */
    protected abstract void render(T data);

    /** Call at the end of each subclass constructor. */
    protected final void start() {
        setVisible(true);
        refresh();
        poll.start();
    }

    protected final void refresh() {
        if (loading) return;
        loading = true;
        Async.run(this::fetch, data -> { loading = false; render(data); }, e -> { loading = false; say("Could not refresh: " + e.getMessage(), true); });
    }

    protected final void act(Callable<?> action) { act(action, "Done", null); }

    protected final void act(Callable<?> action, String okMessage) { act(action, okMessage, null); }

    /** Run a change in the background, show the result message, then refresh. Errors appear in a dialog. */
    protected final void act(Callable<?> action, String okMessage, Runnable afterOk) {
        Async.run(action, result -> {
            String msg = (result instanceof Map<?, ?> m && m.get("message") != null) ? String.valueOf(m.get("message")) : okMessage;
            say(msg, false);
            if (afterOk != null) afterOk.run();
            refresh();
        }, this::fail);
    }

    protected final void fail(Exception e) {
        String msg = e.getMessage() == null ? e.toString() : e.getMessage();
        if (e instanceof java.sql.SQLException) { e.printStackTrace(); msg = "Database error: " + msg; }
        JOptionPane.showMessageDialog(this, msg, "Cannot do that", JOptionPane.WARNING_MESSAGE);
    }

    protected final void say(String msg, boolean error) {
        footer.setForeground(error ? Theme.DANGER : Theme.OK);
        footer.setText(msg);
        footerClear.restart();
    }

    protected final void info(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Smart Hospital", JOptionPane.INFORMATION_MESSAGE);
    }
}
