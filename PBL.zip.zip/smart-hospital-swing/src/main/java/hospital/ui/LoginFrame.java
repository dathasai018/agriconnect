package hospital.ui;

import hospital.AppContext;
import hospital.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Login for staff / doctors / patients, plus patient sign-up. */
public class LoginFrame extends JFrame {
    private final CardLayout cards = new CardLayout();
    private final JPanel forms = new JPanel(cards);
    private final JButton tabLogin = Theme.button("Log in", false);
    private final JButton tabSignup = Theme.button("Patient sign up", false);
    private final JLabel message = Theme.label(" ", Theme.BODY, Theme.DANGER);

    private final JTextField loginUser = Theme.field(new JTextField());
    private final JPasswordField loginPass = Theme.field(new JPasswordField());
    private final JButton loginBtn = Theme.button("Log in", true);

    private final JTextField suName = Theme.field(new JTextField());
    private final JTextField suAge = Theme.field(new JTextField());
    private final JComboBox<String> suGender = Theme.combo(new JComboBox<>(new String[]{"Male", "Female", "Other"}));
    private final JTextField suUser = Theme.field(new JTextField());
    private final JPasswordField suPass = Theme.field(new JPasswordField());
    private final JButton signupBtn = Theme.button("Create account", true);

    public LoginFrame() {
        super("Smart Hospital - Login");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new GridLayout(1, 2));
        root.add(brandPanel());
        root.add(formPanel());
        setContentPane(root);
        getRootPane().setDefaultButton(loginBtn);

        setSize(960, 600);
        setMinimumSize(new Dimension(820, 560));
        setLocationByPlatform(true);
    }

    private JPanel brandPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Theme.BRAND);
        JLabel logo = new JLabel("+", SwingConstants.CENTER) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        logo.setFont(new Font("Segoe UI", Font.BOLD, 34));
        logo.setForeground(Theme.BRAND);
        logo.setPreferredSize(new Dimension(54, 54));
        logo.setAlignmentX(0f);

        JLabel title = Theme.label("Smart Hospital", new Font("Segoe UI", Font.BOLD, 32), Color.WHITE);
        title.setAlignmentX(0f);
        JLabel text = Theme.label("<html><div style='width:300px'>Emergency care, organised by how serious it is. Choose your doctor, "
                + "see who is free, and get seen in the right order.</div></html>", new Font("Segoe UI", Font.PLAIN, 15), new Color(0xE3F4F7));
        text.setAlignmentX(0f);
        JLabel points = Theme.label("<html><div style='width:300px;line-height:1.7'>&bull; Patients pick a free doctor or let staff choose<br>"
                + "&bull; Doctors take the most serious patients first<br>&bull; Staff see beds, doctors and the queue live</div></html>",
                Theme.BODY, new Color(0xCDE9EE));
        points.setAlignmentX(0f);

        JPanel col = new JPanel();
        col.setOpaque(false);
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        col.add(logo);
        col.add(Box.createVerticalStrut(18));
        col.add(title);
        col.add(Box.createVerticalStrut(10));
        col.add(text);
        col.add(Box.createVerticalStrut(22));
        col.add(points);
        p.add(col);
        return p;
    }

    private JPanel formPanel() {
        tabLogin.addActionListener(e -> switchTab(true));
        tabSignup.addActionListener(e -> switchTab(false));
        tabLogin.putClientProperty("active", true);
        JPanel tabs = new JPanel(new GridLayout(1, 2, 8, 0));
        tabs.setOpaque(false);
        tabs.add(tabLogin);
        tabs.add(tabSignup);

        forms.setOpaque(false);
        forms.add(loginForm(), "login");
        forms.add(signupForm(), "signup");

        JButton another = Theme.button("Open another window (to try several roles at once)", false);
        another.addActionListener(e -> new LoginFrame().setVisible(true));

        JPanel col = Theme.stack(14, tabs, forms, message, another);
        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setBackground(Color.WHITE);
        wrap.setBorder(new EmptyBorder(30, 40, 30, 40));
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH; c.weightx = 1; c.weighty = 1;
        wrap.add(col, c);
        return wrap;
    }

    private JPanel loginForm() {
        loginBtn.addActionListener(e -> doLogin());
        JLabel demo = Theme.label("<html><div style='width:320px;line-height:1.6'><b>Demo accounts</b><br>"
                + "Staff: <code>staff</code> / <code>staff123</code><br>"
                + "Doctors: <code>anita</code>, <code>vikram</code>, <code>meera</code>, <code>sameer</code>, <code>priya</code> / <code>doctor123</code></div></html>",
                Theme.SMALL, Theme.MUTED);
        return Theme.stack(10, Theme.labeled("Username", loginUser), Theme.labeled("Password", loginPass), loginBtn, demo);
    }

    private JPanel signupForm() {
        signupBtn.addActionListener(e -> doSignup());
        JPanel row = new JPanel(new GridLayout(1, 2, 10, 0));
        row.setOpaque(false);
        row.add(Theme.labeled("Age", suAge));
        row.add(Theme.labeled("Gender", suGender));
        return Theme.stack(8, Theme.labeled("Full name", suName), row, Theme.labeled("Choose a username", suUser),
                Theme.labeled("Choose a password (min 6 characters)", suPass), signupBtn);
    }

    private void switchTab(boolean login) {
        cards.show(forms, login ? "login" : "signup");
        getRootPane().setDefaultButton(login ? loginBtn : signupBtn);
        message.setText(" ");
        tabLogin.putClientProperty("active", login);
        tabSignup.putClientProperty("active", !login);
        repaint();
    }

    private void doLogin() {
        String u = loginUser.getText(), p = new String(loginPass.getPassword());
        enter(() -> AppContext.auth.login(u, p));
    }

    private void doSignup() {
        String name = suName.getText(), user = suUser.getText(), pass = new String(suPass.getPassword());
        String gender = String.valueOf(suGender.getSelectedItem()).toUpperCase();
        int age;
        try { age = Integer.parseInt(suAge.getText().trim()); }
        catch (NumberFormatException e) { message.setText("Age must be a number"); return; }
        int ageFinal = age;
        enter(() -> {
            AppContext.auth.signup(user, pass, name, ageFinal, gender);
            return AppContext.auth.login(user, pass);
        });
    }

    /** Run a login (or sign-up + login) in the background and open the right window for the user's role. */
    private void enter(java.util.concurrent.Callable<String> job) {
        message.setText(" ");
        loginBtn.setEnabled(false);
        signupBtn.setEnabled(false);
        Async.run(job, token -> {
            User u = AppContext.auth.session(token);
            dispose();
            switch (u.role()) {
                case User.STAFF -> new StaffFrame(u, token);
                case User.DOCTOR -> new DoctorFrame(u, token);
                default -> new PatientFrame(u, token);
            }
        }, e -> {
            loginBtn.setEnabled(true);
            signupBtn.setEnabled(true);
            message.setText(e instanceof java.sql.SQLException ? "Database error: " + e.getMessage() : e.getMessage());
        });
    }
}
