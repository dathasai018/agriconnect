package hospital;

import hospital.ui.LoginFrame;
import hospital.ui.Theme;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        Theme.install();
        try {
            AppContext.init();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Could not connect to MySQL.\n\nDid you run schema.sql, and are DB_URL / DB_USER / DB_PASS correct?\n\nReason: " + e.getMessage(),
                    "Smart Hospital", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
