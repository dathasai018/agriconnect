package hospital.db;

import hospital.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;

/** JDBC access for login accounts. */
public class UserDAO {

    /** A user plus the stored password hash and salt (only used while logging in). */
    public record Credentials(User user, String hash, String salt) {}

    public int create(String username, String hash, String salt, String role, String fullName,
                      Integer age, String gender, Integer doctorId) throws SQLException {
        String sql = "INSERT INTO users (username, password_hash, salt, role, full_name, age, gender, doctor_id) "
                   + "VALUES (?,?,?,?,?,?,?,?)";
        try (Connection c = Database.get();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, username);
            ps.setString(2, hash);
            ps.setString(3, salt);
            ps.setString(4, role);
            ps.setString(5, fullName);
            ps.setObject(6, age);
            ps.setObject(7, gender);
            ps.setObject(8, doctorId);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new IllegalArgumentException("That username is already taken");
        }
    }

    public Credentials find(String username) throws SQLException {
        try (Connection c = Database.get();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM users WHERE username = ?")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                int did = rs.getInt("doctor_id");
                Integer doctorId = rs.wasNull() ? null : did;
                int a = rs.getInt("age");
                Integer age = rs.wasNull() ? null : a;
                User u = new User(rs.getInt("id"), rs.getString("username"), rs.getString("role"),
                        rs.getString("full_name"), doctorId, age, rs.getString("gender"));
                return new Credentials(u, rs.getString("password_hash"), rs.getString("salt"));
            }
        }
    }

    public boolean exists(String username) throws SQLException {
        return scalar("SELECT COUNT(*) FROM users WHERE username = ?", username) > 0;
    }

    public boolean existsForDoctor(int doctorId) throws SQLException {
        return scalar("SELECT COUNT(*) FROM users WHERE doctor_id = ?", doctorId) > 0;
    }

    public boolean hasRole(String role) throws SQLException {
        return scalar("SELECT COUNT(*) FROM users WHERE role = ?", role) > 0;
    }

    private int scalar(String sql, Object param) throws SQLException {
        try (Connection c = Database.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setObject(1, param);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }
}
