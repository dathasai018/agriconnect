package hospital.db;

import hospital.model.Bed;
import hospital.model.Doctor;
import hospital.model.Patient;
import hospital.model.Severity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** All JDBC access lives here (Data Access Object pattern). */
public class HospitalDAO {

    private static final String PATIENT_SELECT =
            "SELECT p.*, d.name AS doctor_name, b.bed_no AS bed_no, pd.name AS pref_name FROM patients p "
          + "LEFT JOIN doctors d ON p.doctor_id = d.id "
          + "LEFT JOIN beds b ON p.bed_id = b.id "
          + "LEFT JOIN doctors pd ON p.preferred_doctor_id = pd.id ";

    private Patient mapPatient(ResultSet rs) throws SQLException {
        Patient p = new Patient();
        p.setId(rs.getInt("id"));
        p.setName(rs.getString("name"));
        p.setAge(rs.getInt("age"));
        p.setGender(rs.getString("gender"));
        p.setComplaint(rs.getString("complaint"));
        p.setSeverity(Severity.fromLevel(rs.getInt("severity")));
        p.setStatus(rs.getString("status"));
        p.setArrival(rs.getTimestamp("arrival_time"));
        p.setDischarge(rs.getTimestamp("discharge_time"));
        int did = rs.getInt("doctor_id");
        p.setDoctorId(rs.wasNull() ? null : did);
        int bid = rs.getInt("bed_id");
        p.setBedId(rs.wasNull() ? null : bid);
        p.setDoctorName(rs.getString("doctor_name"));
        p.setBedNo(rs.getString("bed_no"));
        int uid = rs.getInt("user_id");
        p.setUserId(rs.wasNull() ? null : uid);
        int pid = rs.getInt("preferred_doctor_id");
        p.setPreferredDoctorId(rs.wasNull() ? null : pid);
        p.setPreferredDoctorName(rs.getString("pref_name"));
        p.setStaffChoice(rs.getBoolean("staff_choice"));
        return p;
    }

    private void log(Connection c, Integer patientId, String action) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("INSERT INTO treatment_log (patient_id, action) VALUES (?, ?)")) {
            if (patientId == null) ps.setNull(1, java.sql.Types.INTEGER); else ps.setInt(1, patientId);
            ps.setString(2, action);
            ps.executeUpdate();
        }
    }

    // ---------- patients ----------

    public int addPatient(Patient p) throws SQLException {
        try (Connection c = Database.get()) {
            c.setAutoCommit(false);
            try {
                int id;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO patients (name, age, gender, complaint, severity, user_id, preferred_doctor_id, staff_choice) "
                        + "VALUES (?,?,?,?,?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, p.getName());
                    ps.setInt(2, p.getAge());
                    ps.setString(3, p.getGender());
                    ps.setString(4, p.getComplaint());
                    ps.setInt(5, p.getSeverity().level());
                    ps.setObject(6, p.getUserId());
                    ps.setObject(7, p.getPreferredDoctorId());
                    ps.setBoolean(8, p.isStaffChoice());
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        keys.next();
                        id = keys.getInt(1);
                    }
                }
                log(c, id, "Registered " + p.getName() + " (" + p.getSeverity() + ") - " + p.getComplaint());
                c.commit();
                return id;
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    public Patient getPatient(int id) throws SQLException {
        try (Connection c = Database.get();
             PreparedStatement ps = c.prepareStatement(PATIENT_SELECT + "WHERE p.id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapPatient(rs) : null;
            }
        }
    }

    public List<Patient> listPatients(String status) throws SQLException {
        String sql = PATIENT_SELECT + "WHERE p.status = ? ORDER BY "
                + ("DISCHARGED".equals(status) ? "p.discharge_time DESC LIMIT 50" : "p.severity, p.arrival_time");
        List<Patient> list = new ArrayList<>();
        try (Connection c = Database.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapPatient(rs));
            }
        }
        return list;
    }

    /** Assign a waiting patient to a doctor and bed in one transaction (fails cleanly if anything changed meanwhile). */
    public void assign(int patientId, int doctorId, int bedId, String logText) throws SQLException {
        try (Connection c = Database.get()) {
            c.setAutoCommit(false);
            try {
                if (update(c, "UPDATE patients SET status='IN_TREATMENT', doctor_id=?, bed_id=? WHERE id=? AND status='WAITING'",
                        doctorId, bedId, patientId) != 1)
                    throw new IllegalArgumentException("Patient is no longer waiting");
                if (update(c, "UPDATE doctors SET status='BUSY' WHERE id=? AND status='AVAILABLE'", doctorId) != 1)
                    throw new IllegalArgumentException("Doctor is no longer available");
                if (update(c, "UPDATE beds SET status='OCCUPIED' WHERE id=? AND status='FREE'", bedId) != 1)
                    throw new IllegalArgumentException("Bed is no longer free");
                log(c, patientId, logText);
                c.commit();
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /** Patient cancels a request that has not started treatment. */
    public void cancel(int patientId, String name) throws SQLException {
        try (Connection c = Database.get()) {
            c.setAutoCommit(false);
            try {
                if (update(c, "UPDATE patients SET status='CANCELLED' WHERE id=? AND status='WAITING'", patientId) != 1)
                    throw new IllegalArgumentException("Only waiting requests can be cancelled");
                log(c, patientId, name + " cancelled the request");
                c.commit();
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    public void updateSeverity(int patientId, int level, String logText) throws SQLException {
        try (Connection c = Database.get()) {
            c.setAutoCommit(false);
            try {
                update(c, "UPDATE patients SET severity=? WHERE id=? AND status='WAITING'", level, patientId);
                log(c, patientId, logText);
                c.commit();
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /** The patient's current WAITING / IN_TREATMENT request, or null. */
    public Patient activeForUser(int userId) throws SQLException {
        return one(PATIENT_SELECT + "WHERE p.user_id = ? AND p.status IN ('WAITING','IN_TREATMENT') ORDER BY p.id DESC LIMIT 1", userId);
    }

    public Patient currentForDoctor(int doctorId) throws SQLException {
        return one(PATIENT_SELECT + "WHERE p.doctor_id = ? AND p.status = 'IN_TREATMENT' LIMIT 1", doctorId);
    }

    public List<Patient> historyForUser(int userId) throws SQLException {
        List<Patient> list = new ArrayList<>();
        try (Connection c = Database.get();
             PreparedStatement ps = c.prepareStatement(PATIENT_SELECT + "WHERE p.user_id = ? ORDER BY p.id DESC LIMIT 15")) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapPatient(rs));
            }
        }
        return list;
    }

    private Patient one(String sql, int param) throws SQLException {
        try (Connection c = Database.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, param);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapPatient(rs) : null;
            }
        }
    }

    /** Discharge a patient, free the bed and free the doctor. */
    public void discharge(int patientId) throws SQLException {
        try (Connection c = Database.get()) {
            c.setAutoCommit(false);
            try {
                Integer doctorId = null, bedId = null;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT doctor_id, bed_id FROM patients WHERE id=? AND status='IN_TREATMENT' FOR UPDATE")) {
                    ps.setInt(1, patientId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new IllegalArgumentException("Patient is not in treatment");
                        int d = rs.getInt(1); if (!rs.wasNull()) doctorId = d;
                        int b = rs.getInt(2); if (!rs.wasNull()) bedId = b;
                    }
                }
                update(c, "UPDATE patients SET status='DISCHARGED', discharge_time=CURRENT_TIMESTAMP WHERE id=?", patientId);
                if (bedId != null) update(c, "UPDATE beds SET status='FREE' WHERE id=?", bedId);
                if (doctorId != null) {
                    update(c, "UPDATE doctors SET status='AVAILABLE' WHERE id=? AND status='BUSY' "
                            + "AND NOT EXISTS (SELECT 1 FROM patients WHERE doctor_id=? AND status='IN_TREATMENT')",
                            doctorId, doctorId);
                }
                log(c, patientId, "Discharged");
                c.commit();
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    // ---------- doctors & beds ----------

    private Doctor mapDoctor(ResultSet rs) throws SQLException {
        return new Doctor(rs.getInt("id"), rs.getString("name"), rs.getString("specialization"),
                rs.getString("status"), rs.getString("qualification"), rs.getInt("experience_years"),
                rs.getString("about"), rs.getString("room"));
    }

    public List<Doctor> listDoctors() throws SQLException {
        List<Doctor> list = new ArrayList<>();
        try (Connection c = Database.get();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM doctors ORDER BY id")) {
            while (rs.next()) list.add(mapDoctor(rs));
        }
        return list;
    }

    public Doctor getDoctor(int id) throws SQLException {
        try (Connection c = Database.get(); PreparedStatement ps = c.prepareStatement("SELECT * FROM doctors WHERE id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapDoctor(rs) : null;
            }
        }
    }

    public List<Bed> listBeds() throws SQLException {
        List<Bed> list = new ArrayList<>();
        try (Connection c = Database.get();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM beds ORDER BY id")) {
            while (rs.next()) {
                list.add(new Bed(rs.getInt("id"), rs.getString("bed_no"),
                        rs.getString("ward"), rs.getString("status")));
            }
        }
        return list;
    }

    public void setDoctorStatus(int doctorId, String status, String doctorName) throws SQLException {
        try (Connection c = Database.get()) {
            c.setAutoCommit(false);
            try {
                int n = update(c, "UPDATE doctors SET status=? WHERE id=?", status, doctorId);
                if (n == 0) throw new IllegalArgumentException("Doctor not found");
                log(c, null, doctorName + " is now " + status.replace('_', ' '));
                c.commit();
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    // ---------- stats & log ----------

    public Map<String, Object> stats() throws SQLException {
        Map<String, Object> m = new LinkedHashMap<>();
        try (Connection c = Database.get()) {
            m.put("waiting", count(c, "SELECT COUNT(*) FROM patients WHERE status='WAITING'"));
            m.put("criticalWaiting", count(c, "SELECT COUNT(*) FROM patients WHERE status='WAITING' AND severity=1"));
            m.put("inTreatment", count(c, "SELECT COUNT(*) FROM patients WHERE status='IN_TREATMENT'"));
            m.put("dischargedToday", count(c, "SELECT COUNT(*) FROM patients WHERE status='DISCHARGED' AND DATE(discharge_time)=CURDATE()"));
            m.put("doctorsAvailable", count(c, "SELECT COUNT(*) FROM doctors WHERE status='AVAILABLE'"));
            m.put("doctorsTotal", count(c, "SELECT COUNT(*) FROM doctors"));
            m.put("bedsFree", count(c, "SELECT COUNT(*) FROM beds WHERE status='FREE'"));
            m.put("bedsTotal", count(c, "SELECT COUNT(*) FROM beds"));
        }
        return m;
    }

    public List<Map<String, Object>> recentLog(int limit) throws SQLException {
        List<Map<String, Object>> list = new ArrayList<>();
        try (Connection c = Database.get();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT l.id, l.patient_id, l.action, l.log_time FROM treatment_log l ORDER BY l.id DESC LIMIT ?")) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("id", rs.getInt("id"));
                    int pid = rs.getInt("patient_id");
                    m.put("patientId", rs.wasNull() ? null : pid);
                    m.put("action", rs.getString("action"));
                    m.put("time", rs.getTimestamp("log_time").toLocalDateTime().toString().replace('T', ' '));
                    list.add(m);
                }
            }
        }
        return list;
    }

    // ---------- helpers ----------

    private int count(Connection c, String sql) throws SQLException {
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            rs.next();
            return rs.getInt(1);
        }
    }

    private int update(Connection c, String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
            return ps.executeUpdate();
        }
    }
}
