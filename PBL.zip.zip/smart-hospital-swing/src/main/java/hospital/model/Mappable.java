package hospital.model;

import java.util.Map;

/** Anything that can be turned into a JSON-friendly map. */
public interface Mappable {
    Map<String, Object> toMap();
}
