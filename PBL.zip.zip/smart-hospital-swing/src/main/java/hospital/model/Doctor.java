package hospital.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class Doctor extends Resource {
    private final String name;
    private final String specialization;
    private final String status; // AVAILABLE, BUSY, OFF_DUTY
    private final String qualification;
    private final int experienceYears;
    private final String about;
    private final String room;

    public Doctor(int id, String name, String specialization, String status,
                  String qualification, int experienceYears, String about, String room) {
        super(id);
        this.name = name;
        this.specialization = specialization;
        this.status = status;
        this.qualification = qualification;
        this.experienceYears = experienceYears;
        this.about = about;
        this.room = room;
    }

    public String getName() { return name; }
    public String getSpecialization() { return specialization; }
    public String getStatus() { return status; }

    @Override public String label() { return name; }

    @Override public boolean isAvailable() { return "AVAILABLE".equals(status); }

    @Override
    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("name", name);
        m.put("specialization", specialization);
        m.put("status", status);
        m.put("qualification", qualification);
        m.put("experience", experienceYears);
        m.put("about", about);
        m.put("room", room);
        return m;
    }
}
