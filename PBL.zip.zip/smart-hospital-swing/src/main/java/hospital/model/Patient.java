package hospital.model;

import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class Patient implements Mappable {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private int id;
    private String name;
    private int age;
    private String gender;
    private String complaint;
    private Severity severity;
    private String status;
    private Timestamp arrival;
    private Timestamp discharge;
    private Integer doctorId;
    private Integer bedId;
    private String doctorName;
    private String bedNo;
    private Integer userId;
    private Integer preferredDoctorId;
    private String preferredDoctorName;
    private boolean staffChoice;

    public Patient() {}

    public Patient(String name, int age, String gender, String complaint, Severity severity) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.complaint = complaint;
        this.severity = severity;
        this.status = "WAITING";
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    public String getComplaint() { return complaint; }
    public void setComplaint(String complaint) { this.complaint = complaint; }
    public Severity getSeverity() { return severity; }
    public void setSeverity(Severity severity) { this.severity = severity; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Timestamp getArrival() { return arrival; }
    public void setArrival(Timestamp arrival) { this.arrival = arrival; }
    public Timestamp getDischarge() { return discharge; }
    public void setDischarge(Timestamp discharge) { this.discharge = discharge; }
    public Integer getDoctorId() { return doctorId; }
    public void setDoctorId(Integer doctorId) { this.doctorId = doctorId; }
    public Integer getBedId() { return bedId; }
    public void setBedId(Integer bedId) { this.bedId = bedId; }
    public String getDoctorName() { return doctorName; }
    public void setDoctorName(String doctorName) { this.doctorName = doctorName; }
    public String getBedNo() { return bedNo; }
    public void setBedNo(String bedNo) { this.bedNo = bedNo; }
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }
    public Integer getPreferredDoctorId() { return preferredDoctorId; }
    public void setPreferredDoctorId(Integer id) { this.preferredDoctorId = id; }
    public String getPreferredDoctorName() { return preferredDoctorName; }
    public void setPreferredDoctorName(String n) { this.preferredDoctorName = n; }
    public boolean isStaffChoice() { return staffChoice; }
    public void setStaffChoice(boolean staffChoice) { this.staffChoice = staffChoice; }

    @Override
    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("name", name);
        m.put("age", age);
        m.put("gender", gender);
        m.put("complaint", complaint);
        m.put("severity", severity.level());
        m.put("severityLabel", severity.name());
        m.put("status", status);
        m.put("arrival", arrival == null ? null : arrival.toLocalDateTime().format(FMT));
        m.put("discharge", discharge == null ? null : discharge.toLocalDateTime().format(FMT));
        m.put("doctor", doctorName);
        m.put("bed", bedNo);
        m.put("preferredDoctorId", preferredDoctorId);
        m.put("requested", preferredDoctorName != null ? preferredDoctorName : "Any doctor (staff choice)");
        m.put("selfService", userId != null);
        return m;
    }
}
