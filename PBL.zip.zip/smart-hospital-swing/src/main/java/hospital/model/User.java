package hospital.model;

import java.util.LinkedHashMap;
import java.util.Map;

/** A logged-in account. role is STAFF, DOCTOR or PATIENT; doctorId is set only for doctors. */
public record User(int id, String username, String role, String fullName,
                   Integer doctorId, Integer age, String gender) implements Mappable {

    public static final String STAFF = "STAFF", DOCTOR = "DOCTOR", PATIENT = "PATIENT";

    @Override
    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("username", username);
        m.put("role", role);
        m.put("fullName", fullName);
        m.put("doctorId", doctorId);
        m.put("age", age);
        m.put("gender", gender);
        return m;
    }
}
