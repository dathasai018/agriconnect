package hospital.model;

/** Base class for anything a patient can be assigned to (doctor, bed). Demonstrates abstraction + polymorphism. */
public abstract class Resource implements Mappable {
    protected final int id;

    protected Resource(int id) { this.id = id; }

    public int getId() { return id; }

    public abstract String label();

    public abstract boolean isAvailable();
}
