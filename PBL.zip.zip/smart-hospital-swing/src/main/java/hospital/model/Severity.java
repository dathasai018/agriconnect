package hospital.model;

public enum Severity {
    CRITICAL(1), SEVERE(2), MODERATE(3), MINOR(4);

    private final int level;

    Severity(int level) { this.level = level; }

    public int level() { return level; }

    public static Severity fromLevel(int level) {
        for (Severity s : values()) if (s.level == level) return s;
        throw new IllegalArgumentException("Severity must be between 1 (critical) and 4 (minor)");
    }
}
