package hospital.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class Bed extends Resource {
    private final String bedNo;
    private final String ward;   // ICU, EMERGENCY, GENERAL
    private final String status; // FREE, OCCUPIED

    public Bed(int id, String bedNo, String ward, String status) {
        super(id);
        this.bedNo = bedNo;
        this.ward = ward;
        this.status = status;
    }

    public String getBedNo() { return bedNo; }
    public String getWard() { return ward; }
    public String getStatus() { return status; }

    @Override public String label() { return bedNo; }

    @Override public boolean isAvailable() { return "FREE".equals(status); }

    @Override
    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("bedNo", bedNo);
        m.put("ward", ward);
        m.put("status", status);
        return m;
    }
}
