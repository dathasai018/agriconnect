package hospital.ds;

import hospital.model.Patient;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Triage queue built on core data structures:
 *  - PriorityQueue (binary min-heap): most critical patient first, ties broken by earliest arrival (FIFO).
 *  - HashMap: O(1) lookup of a waiting patient by id.
 */
public class TriageQueue {
    private static final Comparator<Patient> ORDER = Comparator
            .comparingInt((Patient p) -> p.getSeverity().level())
            .thenComparing(Patient::getArrival)
            .thenComparingInt(Patient::getId);

    private final PriorityQueue<Patient> heap = new PriorityQueue<>(ORDER);
    private final Map<Integer, Patient> index = new HashMap<>();

    public void add(Patient p) {
        heap.add(p);
        index.put(p.getId(), p);
    }

    public Patient peek() { return heap.peek(); }

    public Patient poll() {
        Patient p = heap.poll();
        if (p != null) index.remove(p.getId());
        return p;
    }

    public boolean contains(int id) { return index.containsKey(id); }

    public Patient get(int id) { return index.get(id); }

    /** Remove a waiting patient (assigned, cancelled or re-triaged). Returns false if not queued. */
    public boolean remove(int id) {
        Patient p = index.remove(id);
        return p != null && heap.remove(p);
    }

    public int size() { return heap.size(); }

    /** Snapshot of the queue in service order (does not modify the queue). */
    public List<Patient> snapshot() {
        List<Patient> list = new ArrayList<>(heap);
        list.sort(ORDER);
        return list;
    }
}
