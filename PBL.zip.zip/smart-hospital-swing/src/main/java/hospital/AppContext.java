package hospital;

import hospital.service.AuthService;
import hospital.service.EmergencyService;

import java.util.List;

/** One shared set of services for every window, so all logged-in users see the same live queue. */
public final class AppContext {
    public static final EmergencyService service = new EmergencyService();
    public static final AuthService auth = new AuthService();

    private AppContext() {}

    /** Load the waiting queue from MySQL and create the default staff / doctor logins on first run. */
    public static void init() throws Exception {
        service.init();
        List<String> created = auth.seedDefaults(service.doctors());
        for (String line : created) System.out.println("Created login: " + line);
    }
}
