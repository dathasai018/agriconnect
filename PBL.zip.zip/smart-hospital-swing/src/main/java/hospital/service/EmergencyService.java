package hospital.service;

import hospital.db.HospitalDAO;
import hospital.ds.TriageQueue;
import hospital.model.Bed;
import hospital.model.Doctor;
import hospital.model.Patient;
import hospital.model.Severity;
import hospital.model.User;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

/**
 * Business logic: triage queue + resource allocation. Methods are synchronized so the queue stays consistent.
 *
 * Who can do what:
 *  - PATIENT: request care, pick a FREE doctor or ask staff to choose, cancel a waiting request.
 *  - DOCTOR : see waiting patients most-serious-first and take one (only from the most serious group), discharge own patient.
 *  - STAFF  : register walk-ins, assign doctors (best match / random / specific), re-triage, discharge, set doctor duty.
 */
public class EmergencyService {
    private final HospitalDAO dao = new HospitalDAO();
    private final TriageQueue queue = new TriageQueue();
    private final Random random = new Random();

    /** Rebuild the in-memory triage queue from the database (so a restart loses nothing). */
    public synchronized void init() throws SQLException {
        for (Patient p : dao.listPatients("WAITING")) queue.add(p);
    }

    // ================= registration =================

    /** Staff registers a walk-in patient (no login). They join the pool any doctor can take. */
    public synchronized Patient registerWalkIn(String name, int age, String gender, String complaint, int severity)
            throws SQLException {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name is required");
        if (age < 0 || age > 150) throw new IllegalArgumentException("Age must be between 0 and 150");
        if (!List.of("MALE", "FEMALE", "OTHER").contains(gender)) throw new IllegalArgumentException("Invalid gender");
        if (complaint == null || complaint.isBlank()) throw new IllegalArgumentException("Complaint is required");
        Patient p = new Patient(name.trim(), age, gender, complaint.trim(), Severity.fromLevel(severity));
        p.setStaffChoice(true);
        return enqueue(p);
    }

    /**
     * A logged-in patient asks for care.
     * mode DOCTOR: the patient picked a doctor, who must be free. mode STAFF: staff will choose a doctor.
     */
    public synchronized Map<String, Object> requestTreatment(User u, String complaint, int severity,
                                                             String mode, Integer doctorId) throws SQLException {
        if (dao.activeForUser(u.id()) != null)
            throw new IllegalArgumentException("You already have an active request. Cancel it or wait until it is finished.");
        if (complaint == null || complaint.isBlank()) throw new IllegalArgumentException("Please describe what is wrong");
        Patient p = new Patient(u.fullName(), u.age() == null ? 0 : u.age(), u.gender() == null ? "OTHER" : u.gender(),
                complaint.trim(), Severity.fromLevel(severity));
        p.setUserId(u.id());

        Doctor chosen = null;
        if ("DOCTOR".equals(mode)) {
            if (doctorId == null) throw new IllegalArgumentException("Please choose a doctor");
            chosen = dao.getDoctor(doctorId);
            if (chosen == null) throw new IllegalArgumentException("Doctor not found");
            if (!chosen.isAvailable())
                throw new IllegalArgumentException(chosen.getName() + " is not free right now. Choose a free doctor or let staff choose for you.");
            p.setPreferredDoctorId(chosen.getId());
        } else if ("STAFF".equals(mode)) {
            p.setStaffChoice(true);
        } else {
            throw new IllegalArgumentException("Please choose a doctor or ask staff to choose");
        }

        Patient saved = enqueue(p);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("assigned", false);
        if (chosen == null) {
            result.put("message", "Request received. Staff will assign a doctor for you.");
            return result;
        }
        // A more serious patient who could use this doctor always goes first.
        if (moreSeriousWaiting(chosen, saved)) {
            result.put("message", "A more serious patient is ahead of you. You are in line for " + chosen.getName() + ".");
            return result;
        }
        Bed bed = pickBed(dao.listBeds(), saved);
        if (bed == null) {
            result.put("message", "No bed is free yet. You are in line for " + chosen.getName() + ".");
            return result;
        }
        result.put("assigned", true);
        result.put("message", doAssign(saved, chosen, bed));
        return result;
    }

    public synchronized void cancelMine(User u) throws SQLException {
        Patient p = dao.activeForUser(u.id());
        if (p == null) throw new IllegalArgumentException("You have no active request");
        if (!"WAITING".equals(p.getStatus()))
            throw new IllegalArgumentException("Treatment has already started. Please speak to the staff.");
        dao.cancel(p.getId(), p.getName());
        queue.remove(p.getId());
    }

    // ================= staff assignment =================

    /** Assign the most serious patient who can actually be placed right now (skips patients waiting for a busy doctor). */
    public synchronized Map<String, Object> assignNext() throws SQLException {
        Map<String, Object> result = new LinkedHashMap<>();
        List<Patient> waiting = queue.snapshot();
        if (waiting.isEmpty()) return fail(result, "No patients are waiting.");

        List<Doctor> doctors = dao.listDoctors();
        List<Bed> beds = dao.listBeds();
        for (Patient p : waiting) {
            Doctor d = p.getPreferredDoctorId() != null
                    ? doctors.stream().filter(x -> x.getId() == p.getPreferredDoctorId() && x.isAvailable()).findFirst().orElse(null)
                    : bestMatch(doctors, p);
            Bed b = pickBed(beds, p);
            if (d != null && b != null) {
                result.put("assigned", true);
                result.put("message", doAssign(p, d, b));
                return result;
            }
        }
        return fail(result, "Nobody in the queue can be placed right now (no free doctor or bed for them).");
    }

    /** Staff assigns a specific waiting patient. doctorSpec: "auto" (best match), "random", or a doctor id. */
    public synchronized Map<String, Object> assignTo(int patientId, String doctorSpec) throws SQLException {
        Patient p = queue.get(patientId);
        if (p == null) throw new IllegalArgumentException("That patient is not waiting");
        List<Doctor> doctors = dao.listDoctors();
        List<Doctor> free = new ArrayList<>();
        for (Doctor d : doctors) if (d.isAvailable()) free.add(d);

        Doctor doctor;
        if ("auto".equals(doctorSpec)) {
            doctor = bestMatch(doctors, p);
        } else if ("random".equals(doctorSpec)) {
            doctor = free.isEmpty() ? null : free.get(random.nextInt(free.size()));
        } else {
            int id;
            try { id = Integer.parseInt(doctorSpec); } catch (Exception e) { throw new IllegalArgumentException("Choose a doctor"); }
            doctor = free.stream().filter(d -> d.getId() == id).findFirst().orElse(null);
            if (doctor == null) throw new IllegalArgumentException("That doctor is not available");
        }
        if (doctor == null) throw new IllegalArgumentException("No doctor is available right now");
        Bed bed = pickBed(dao.listBeds(), p);
        if (bed == null) throw new IllegalArgumentException("No bed is free right now");

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("assigned", true);
        result.put("message", doAssign(p, doctor, bed));
        return result;
    }

    public synchronized void changeSeverity(int patientId, int level) throws SQLException {
        Severity s = Severity.fromLevel(level);
        Patient p = queue.get(patientId);
        if (p == null) throw new IllegalArgumentException("Only waiting patients can be re-triaged");
        if (p.getSeverity() == s) return;
        // remove first: the heap order depends on severity, so never change it while the patient is inside the heap
        queue.remove(patientId);
        dao.updateSeverity(patientId, level, "Re-triaged " + p.getName() + " from " + p.getSeverity() + " to " + s);
        queue.add(dao.getPatient(patientId));
    }

    // ================= doctor actions =================

    /** A doctor picks a waiting patient. Only patients from the most serious group they may treat can be picked. */
    public synchronized Map<String, Object> doctorTake(User actor, int patientId) throws SQLException {
        Doctor me = dao.getDoctor(actor.doctorId());
        if (me == null) throw new IllegalArgumentException("Doctor profile not found");
        if ("BUSY".equals(me.getStatus())) throw new IllegalArgumentException("Finish and discharge your current patient first.");
        if (!me.isAvailable()) throw new IllegalArgumentException("Set yourself to Available before taking patients.");

        List<Patient> eligible = eligibleFor(me);
        Patient target = eligible.stream().filter(p -> p.getId() == patientId).findFirst().orElse(null);
        if (target == null) throw new IllegalArgumentException("That patient is no longer waiting for you.");
        if (target.getSeverity().level() > eligible.get(0).getSeverity().level())
            throw new IllegalArgumentException("More serious patients are waiting. Please treat them first.");
        Bed bed = pickBed(dao.listBeds(), target);
        if (bed == null) throw new IllegalArgumentException("No bed is free right now.");

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("assigned", true);
        result.put("message", doAssign(target, me, bed));
        return result;
    }

    public synchronized void discharge(User actor, int patientId) throws SQLException {
        if (User.DOCTOR.equals(actor.role())) {
            Patient p = dao.getPatient(patientId);
            if (p == null || !Objects.equals(p.getDoctorId(), actor.doctorId()))
                throw new SecurityException("You can only discharge your own patients");
        }
        dao.discharge(patientId);
    }

    public synchronized void setDoctorStatus(User actor, int doctorId, String status) throws SQLException {
        if (User.DOCTOR.equals(actor.role()) && !Objects.equals(actor.doctorId(), doctorId))
            throw new SecurityException("You can only change your own status");
        if (!List.of("AVAILABLE", "OFF_DUTY").contains(status))
            throw new IllegalArgumentException("Status can only be set to AVAILABLE or OFF_DUTY");
        Doctor d = dao.getDoctor(doctorId);
        if (d == null) throw new IllegalArgumentException("Doctor not found");
        if ("BUSY".equals(d.getStatus()))
            throw new IllegalArgumentException(d.getName() + " is treating a patient. Discharge the patient first.");
        dao.setDoctorStatus(doctorId, status, d.getName());
    }

    // ================= views for each role =================

    public synchronized Map<String, Object> staffView() throws SQLException {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("stats", dao.stats());
        m.put("queue", queue.snapshot());
        m.put("inTreatment", dao.listPatients("IN_TREATMENT"));
        m.put("discharged", dao.listPatients("DISCHARGED"));
        m.put("doctors", dao.listDoctors());
        m.put("beds", dao.listBeds());
        m.put("log", dao.recentLog(30));
        return m;
    }

    public synchronized Map<String, Object> doctorView(User u) throws SQLException {
        Doctor me = dao.getDoctor(u.doctorId());
        if (me == null) throw new IllegalArgumentException("Doctor profile not found");
        List<Patient> eligible = eligibleFor(me);
        int top = eligible.isEmpty() ? 0 : eligible.get(0).getSeverity().level();

        List<Map<String, Object>> rows = new ArrayList<>();
        for (Patient p : eligible) {
            Map<String, Object> pm = p.toMap();
            pm.put("canTake", me.isAvailable() && p.getSeverity().level() == top);
            pm.put("forYou", p.getPreferredDoctorId() != null);
            rows.add(pm);
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("me", me);
        m.put("current", dao.currentForDoctor(me.getId()));
        m.put("queue", rows);
        m.put("freeBeds", dao.stats().get("bedsFree"));
        return m;
    }

    public synchronized Map<String, Object> patientView(User u) throws SQLException {
        Patient active = dao.activeForUser(u.id());
        Map<String, Object> activeMap = null;
        if (active != null) {
            activeMap = active.toMap();
            if ("WAITING".equals(active.getStatus())) {
                int pos = 0, i = 1;
                for (Patient p : queue.snapshot()) { if (p.getId() == active.getId()) pos = i; i++; }
                activeMap.put("position", pos);
            }
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("active", activeMap);
        m.put("history", dao.historyForUser(u.id()));
        m.put("doctors", dao.listDoctors());
        return m;
    }

    public List<Doctor> doctors() throws SQLException { return dao.listDoctors(); }

    // ================= internals =================

    private Patient enqueue(Patient p) throws SQLException {
        int id = dao.addPatient(p);
        Patient saved = dao.getPatient(id);
        queue.add(saved);
        return saved;
    }

    private String doAssign(Patient p, Doctor d, Bed b) throws SQLException {
        String text = p.getName() + " assigned to " + d.label() + " in bed " + b.label();
        dao.assign(p.getId(), d.getId(), b.getId(), text);
        queue.remove(p.getId());
        return p.getName() + " assigned to " + d.label() + " in " + b.label() + ".";
    }

    private Map<String, Object> fail(Map<String, Object> result, String msg) {
        result.put("assigned", false);
        result.put("message", msg);
        return result;
    }

    /** Waiting patients this doctor may treat (chose this doctor, or left it to staff), most serious first. */
    private List<Patient> eligibleFor(Doctor d) {
        List<Patient> list = new ArrayList<>();
        for (Patient p : queue.snapshot())
            if (p.getPreferredDoctorId() == null || p.getPreferredDoctorId() == d.getId()) list.add(p);
        return list;
    }

    private boolean moreSeriousWaiting(Doctor d, Patient me) {
        for (Patient p : eligibleFor(d))
            if (p.getId() != me.getId() && p.getSeverity().level() < me.getSeverity().level()) return true;
        return false;
    }

    /** Best-match policy: emergency/trauma for critical+severe, pediatrics for under 15, otherwise any free doctor. */
    private Doctor bestMatch(List<Doctor> doctors, Patient p) {
        Doctor fallback = null;
        for (Doctor d : doctors) {
            if (!d.isAvailable()) continue;
            if (fallback == null) fallback = d;
            String spec = d.getSpecialization().toLowerCase();
            if (p.getSeverity().level() <= 2 && (spec.contains("emergency") || spec.contains("trauma"))) return d;
            if (p.getAge() < 15 && spec.contains("pediatric")) return d;
        }
        return fallback;
    }

    /** Critical -> ICU, severe/moderate -> Emergency, minor -> General; fall back to any free bed. */
    private Bed pickBed(List<Bed> beds, Patient p) {
        String[] pref = switch (p.getSeverity()) {
            case CRITICAL -> new String[]{"ICU", "EMERGENCY", "GENERAL"};
            case SEVERE, MODERATE -> new String[]{"EMERGENCY", "GENERAL", "ICU"};
            case MINOR -> new String[]{"GENERAL", "EMERGENCY", "ICU"};
        };
        for (String ward : pref)
            for (Bed b : beds) if (b.isAvailable() && b.getWard().equals(ward)) return b;
        return null;
    }
}
