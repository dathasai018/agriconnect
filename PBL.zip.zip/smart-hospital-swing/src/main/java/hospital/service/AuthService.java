package hospital.service;

import hospital.db.UserDAO;
import hospital.model.Doctor;
import hospital.model.User;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.SQLException;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Sign-up, login, logout and in-memory sessions. Passwords are stored as salted PBKDF2 hashes. */
public class AuthService {
    public static final String DEFAULT_STAFF_USER = "staff", DEFAULT_STAFF_PASS = "staff123";
    public static final String DEFAULT_DOCTOR_PASS = "doctor123";

    private static final long SESSION_MILLIS = 8L * 60 * 60 * 1000;
    private static final SecureRandom RNG = new SecureRandom();

    private record Session(User user, long expiresAt) {}

    private final UserDAO users = new UserDAO();
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    /** Create one staff account and one login per doctor the first time the app runs. Returns lines to print. */
    public List<String> seedDefaults(List<Doctor> doctors) throws SQLException {
        List<String> created = new java.util.ArrayList<>();
        if (!users.hasRole(User.STAFF)) {
            createUser(DEFAULT_STAFF_USER, DEFAULT_STAFF_PASS, User.STAFF, "Front Desk Staff", null, null, null);
            created.add("staff   -> username: " + DEFAULT_STAFF_USER + "   password: " + DEFAULT_STAFF_PASS);
        }
        for (Doctor d : doctors) {
            if (users.existsForDoctor(d.getId())) continue;
            String[] parts = d.getName().replace("Dr.", "").trim().toLowerCase().split("\\s+");
            String username = parts[0];
            if (users.exists(username)) username = username + d.getId();
            createUser(username, DEFAULT_DOCTOR_PASS, User.DOCTOR, d.getName(), d.getId(), null, null);
            created.add("doctor  -> username: " + username + "   password: " + DEFAULT_DOCTOR_PASS + "   (" + d.getName() + ")");
        }
        return created;
    }

    public User signup(String username, String password, String fullName, int age, String gender) throws SQLException {
        if (fullName == null || fullName.isBlank()) throw new IllegalArgumentException("Full name is required");
        if (age < 0 || age > 150) throw new IllegalArgumentException("Age must be between 0 and 150");
        if (!List.of("MALE", "FEMALE", "OTHER").contains(gender)) throw new IllegalArgumentException("Please select a gender");
        createUser(username, password, User.PATIENT, fullName.trim(), null, age, gender);
        return users.find(username.trim().toLowerCase()).user();
    }

    /** Returns a new session token, or throws IllegalArgumentException for wrong credentials. */
    public String login(String username, String password) throws SQLException {
        UserDAO.Credentials cr = (username == null || password == null) ? null : users.find(username.trim().toLowerCase());
        // Always do the hashing work so the response time does not reveal whether the username exists.
        byte[] salt = cr == null ? new byte[16] : HexFormat.of().parseHex(cr.salt());
        String attempt = hash(password == null ? "" : password, salt);
        boolean ok = cr != null && MessageDigest.isEqual(attempt.getBytes(), cr.hash().getBytes());
        if (!ok) throw new IllegalArgumentException("Wrong username or password");

        byte[] raw = new byte[32];
        RNG.nextBytes(raw);
        String token = HexFormat.of().formatHex(raw);
        sessions.put(token, new Session(cr.user(), System.currentTimeMillis() + SESSION_MILLIS));
        return token;
    }

    public User session(String token) {
        if (token == null) return null;
        Session s = sessions.get(token);
        if (s == null) return null;
        if (s.expiresAt() < System.currentTimeMillis()) { sessions.remove(token); return null; }
        return s.user();
    }

    public void logout(String token) {
        if (token != null) sessions.remove(token);
    }

    // ---------------- helpers ----------------

    private void createUser(String username, String password, String role, String fullName,
                            Integer doctorId, Integer age, String gender) throws SQLException {
        String u = username == null ? "" : username.trim().toLowerCase();
        if (!u.matches("[a-z0-9_.-]{3,30}")) throw new IllegalArgumentException("Username must be 3-30 letters, numbers, dots, dashes or underscores");
        if (password == null || password.length() < 6) throw new IllegalArgumentException("Password must be at least 6 characters");
        byte[] salt = new byte[16];
        RNG.nextBytes(salt);
        users.create(u, hash(password, salt), HexFormat.of().formatHex(salt), role, fullName, age, gender, doctorId);
    }

    private static String hash(String password, byte[] salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 60_000, 256);
            byte[] h = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return HexFormat.of().formatHex(h);
        } catch (Exception e) {
            throw new IllegalStateException("Password hashing is unavailable", e);
        }
    }
}
