@echo off
REM Starts the Smart Hospital desktop app (needs JDK 17+, Maven and MySQL with schema.sql already imported).
set /p DB_PASS=Enter your MySQL root password (press Enter if none): 
call mvn -q compile exec:java
pause
