-- Smart Hospital Emergency Management System : MySQL schema + seed data
-- WARNING: running this file resets all data.
CREATE DATABASE IF NOT EXISTS smart_hospital;
USE smart_hospital;

DROP TABLE IF EXISTS treatment_log;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS beds;
DROP TABLE IF EXISTS doctors;

CREATE TABLE doctors (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    name             VARCHAR(80)  NOT NULL,
    specialization   VARCHAR(60)  NOT NULL,
    qualification    VARCHAR(120) NOT NULL DEFAULT '',
    experience_years INT          NOT NULL DEFAULT 0,
    about            VARCHAR(255) NOT NULL DEFAULT '',
    room             VARCHAR(20)  NOT NULL DEFAULT '',
    status           ENUM('AVAILABLE','BUSY','OFF_DUTY') NOT NULL DEFAULT 'AVAILABLE'
);

CREATE TABLE beds (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    bed_no  VARCHAR(10) NOT NULL UNIQUE,
    ward    ENUM('ICU','EMERGENCY','GENERAL') NOT NULL,
    status  ENUM('FREE','OCCUPIED') NOT NULL DEFAULT 'FREE'
);

-- Login accounts. Passwords are stored as salted PBKDF2 hashes (never plain text).
CREATE TABLE users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(40) NOT NULL UNIQUE,
    password_hash CHAR(64)    NOT NULL,
    salt          CHAR(32)    NOT NULL,
    role          ENUM('STAFF','DOCTOR','PATIENT') NOT NULL,
    full_name     VARCHAR(80) NOT NULL,
    age           INT NULL,
    gender        ENUM('MALE','FEMALE','OTHER') NULL,
    doctor_id     INT NULL UNIQUE,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_user_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);

CREATE TABLE patients (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    user_id             INT NULL,                 -- NULL = walk-in registered by staff
    name                VARCHAR(80)  NOT NULL,
    age                 INT          NOT NULL CHECK (age BETWEEN 0 AND 150),
    gender              ENUM('MALE','FEMALE','OTHER') NOT NULL,
    complaint           VARCHAR(255) NOT NULL,
    severity            TINYINT      NOT NULL CHECK (severity BETWEEN 1 AND 4), -- 1 = CRITICAL ... 4 = MINOR
    status              ENUM('WAITING','IN_TREATMENT','DISCHARGED','CANCELLED') NOT NULL DEFAULT 'WAITING',
    preferred_doctor_id INT NULL,                 -- doctor the patient chose
    staff_choice        BOOLEAN NOT NULL DEFAULT FALSE, -- patient asked staff to pick a doctor
    arrival_time        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    discharge_time      TIMESTAMP    NULL,
    doctor_id           INT NULL,
    bed_id              INT NULL,
    CONSTRAINT fk_patient_user      FOREIGN KEY (user_id)             REFERENCES users(id),
    CONSTRAINT fk_patient_doctor    FOREIGN KEY (doctor_id)           REFERENCES doctors(id),
    CONSTRAINT fk_patient_preferred FOREIGN KEY (preferred_doctor_id) REFERENCES doctors(id),
    CONSTRAINT fk_patient_bed       FOREIGN KEY (bed_id)              REFERENCES beds(id)
);

CREATE TABLE treatment_log (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NULL,
    action     VARCHAR(255) NOT NULL,
    log_time   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_log_patient FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE INDEX idx_patient_status ON patients(status, severity, arrival_time);
CREATE INDEX idx_patient_user   ON patients(user_id, status);

INSERT INTO doctors (name, specialization, qualification, experience_years, about, room) VALUES
 ('Dr. Anita Rao',    'Emergency Medicine', 'MD, Emergency Medicine',      12, 'Acute emergencies, breathing difficulty, poisoning and first-response care.', 'ER-A'),
 ('Dr. Vikram Singh', 'Cardiology',         'DM, Cardiology',              15, 'Chest pain, heart attacks, palpitations and blood pressure emergencies.',    'C-2'),
 ('Dr. Meera Nair',   'Trauma Surgery',     'MS, MCh Trauma Surgery',      10, 'Accident injuries, fractures, deep wounds and emergency surgery.',           'T-1'),
 ('Dr. Sameer Khan',  'General Medicine',   'MD, General Medicine',         8, 'Fever, infections, stomach pain, dehydration and general illness.',          'G-3'),
 ('Dr. Priya Sharma', 'Pediatrics',         'MD, Pediatrics',               9, 'Medical care for infants, children and teenagers.',                          'P-1');

INSERT INTO beds (bed_no, ward) VALUES
 ('ICU-1','ICU'),('ICU-2','ICU'),
 ('ER-1','EMERGENCY'),('ER-2','EMERGENCY'),('ER-3','EMERGENCY'),('ER-4','EMERGENCY'),
 ('GEN-1','GENERAL'),('GEN-2','GENERAL'),('GEN-3','GENERAL');

-- Login accounts for staff and doctors are created automatically the first time the app starts
-- (see AuthService.seedDefaults). Patients create their own accounts on the sign-up page.
