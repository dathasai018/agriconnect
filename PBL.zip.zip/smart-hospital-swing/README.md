# Smart Hospital Emergency Management System (Java Swing desktop app)

A desktop (Swing) application with **login for three roles**, backed by MySQL.

| Role | What they can do |
|---|---|
| **Patient** (self sign-up) | Describe the problem, mark how serious it is, see every doctor (specialization, qualification, experience, room, free/busy). Pick a **free** doctor or let **staff choose**. See queue position, cancel a waiting request, view visit history. |
| **Doctor** | See waiting patients **most serious first**. Take a patient (only from the most serious group; others stay locked). Discharge own patient, go on/off duty. |
| **Staff** | Live stats, triage queue, assign doctor (best match / random free doctor / specific), auto-assign next, change severity, register walk-ins, discharge, set doctors on/off duty, beds, activity log. |

## Requirements
JDK 17+, Maven, MySQL 8.

## 1. Create the database (resets all data)
Open a terminal in this folder (the one containing `pom.xml` and `schema.sql`):

    cmd /c "mysql -u root -p < schema.sql"        (Windows PowerShell)
    mysql -u root -p < schema.sql                  (cmd / Mac / Linux)

## 2. Run the app

### Eclipse
1. File > Import > Maven > Existing Maven Projects > select this folder > Finish (wait for downloads).
2. Right-click `src/main/java/hospital/Main.java` > Run As > Run Configurations > Java Application.
3. Environment tab > New: Name `DB_PASS`, Value = your MySQL password. Apply, Run.

### VS Code
Install "Extension Pack for Java", open this folder, press F5 (it asks for your MySQL password).

### Terminal / double-click
    run.bat                      (Windows - asks for the password)
or
    set DB_PASS=yourpassword     (PowerShell: $env:DB_PASS="yourpassword")
    mvn compile exec:java

The login window opens. If MySQL cannot be reached you get an error box explaining what to check.

## Demo logins
| Role | Username | Password |
|---|---|---|
| Staff | `staff` | `staff123` |
| Doctors | `anita`, `vikram`, `meera`, `sameer`, `priya` | `doctor123` |
| Patient | create one with **Patient sign up** | |

These are created automatically on first start.

## Trying all roles at once
Use ONE running app. On the login window click **Open another window**, and log in as a different role in each window. All windows share the same live queue and refresh every 5 seconds.
(Do not start the program twice: each copy keeps its own queue in memory.)

## Priority rules
* Severity: 1 Critical, 2 Severe, 3 Moderate, 4 Minor. The waiting queue is a priority queue ordered by severity, then arrival time.
* A patient can pick a doctor only if that doctor is **free**. If a more serious patient could use that doctor, the request waits in line instead of jumping ahead.
* "Let staff choose" patients can be taken by any doctor, or assigned by staff.
* A doctor treats one patient at a time. Beds: Critical -> ICU, Severe/Moderate -> Emergency, Minor -> General.

## Configuration (environment variables)
`DB_URL`, `DB_USER` (default root), `DB_PASS`.

## Notes
* Passwords are stored as salted PBKDF2 hashes. Change the demo passwords before real use.
* Patient-entered severity is only a starting point; staff can re-triage.

## Project layout
    hospital/Main.java, AppContext.java     start-up and shared services
    hospital/ui/*                           Swing windows (LoginFrame, PatientFrame, DoctorFrame, StaffFrame)
    hospital/service/*                      business rules (EmergencyService, AuthService)
    hospital/db/*, hospital/ds/*            MySQL access (JDBC) and the priority queue
    schema.sql                              database tables and sample data
